/*
 *
 *
 *
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.text.*;

import java.sql.*;

import uk.co.westhawk.snmp.stack.*;
import uk.co.westhawk.snmp.pdu.*;


class updateBoksmacCache
{
	public static final String navRoot = "/usr/local/nav/";
	public static final String configFile = "local/etc/conf/getBoksMacs.conf";

	public static final boolean DB_UPDATE = true;
	public static final boolean DB_COMMIT = true;

	public static void main(String[] args) throws SQLException
	{
		ConfigParser cp;
		try {
			cp = new ConfigParser(navRoot + configFile);
			//cp = new ConfigParser("c:\\macs.conf");
		} catch (IOException e) {
			outl("Error, could not read config file: " + navRoot + configFile);
			return;
		}
		if (!Database.openConnection(cp.get("SQLServer"), cp.get("SQLDb"), cp.get("SQLUser"), cp.get("SQLPw"))) {
			outl("Error, could not connect to database!");
			return;
		}

		// Update boksmac cache
		outl("Starting update of boksmac_cache, may take a while if arp is large...");
		long beginTime = new java.util.GregorianCalendar().getTime().getTime();
		boolean b = updateBoksMacCache();
		long usedTime = new java.util.GregorianCalendar().getTime().getTime() - beginTime;
		outl("Update boksmac_cache from boksmac: " + (b?"OK":"fail") );

		Database.closeConnection();
		outl("All done, time used: " + formatTime(usedTime) + ".");
		System.exit(0);
	}

	private static boolean updateBoksMacCache() {
		try {
			if (DB_UPDATE) {
				int insCnt = Database.update("INSERT INTO boksmac_cache (SELECT boksid,mac FROM boksmac WHERE (mac) NOT IN (SELECT mac FROM boksmac_cache))");
				outl("Inserted  " + insCnt + " new rows into boksmac_cache.");

				int delCnt = Database.update("DELETE FROM boksmac_cache WHERE (mac) NOT IN (SELECT mac FROM boksmac)");
				outl("Deleted   " + delCnt + " rows from boksmac_cache.");
				if (DB_COMMIT) Database.commit();
			}
		} catch (SQLException e) {
			outl("ERROR, SQLException: " + e.getMessage() );
			return false;
		}
		return true;
	}

	private static String format(long i, int n)
	{
		DecimalFormat nf = new DecimalFormat("#");
		nf.setMinimumIntegerDigits(n);
		return nf.format(i);
	}

	public static String formatTime(long t)
	{
		long h = t / (60 * 60 * 1000);
		t %= 60 * 60 * 1000;

		long m = t / (60 * 1000);
		t %= 60 * 1000;

		long s = t / (1000);
		t %= 1000;

		long ms = t;

		return format(h,2)+":"+format(m,2)+":"+format(s,2)+"."+format(ms,3);
	}

	private static void out(String s) { System.out.print(s); }
	private static void outl(String s) { System.out.println(s); }

}

















