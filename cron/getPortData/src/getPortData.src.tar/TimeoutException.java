public class TimeoutException extends Exception
{
	public TimeoutException(String s) {
		super(s);
	}
}
