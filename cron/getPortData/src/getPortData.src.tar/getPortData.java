/*
 *
 *
 *
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.text.*;

import java.sql.*;

import uk.co.westhawk.snmp.stack.*;
import uk.co.westhawk.snmp.pdu.*;


// select swportid,boksid,sysname,typeid,ifindex,modul,port,status,speed,duplex,media,trunk from swport join boks using (boksid) join type using (typeid) where typegruppe like '3%' and swport.static='f' order by boksid,modul,port;
// select count(*) from swport join boks using (boksid) join type using (typeid) where typegruppe like '3%' and swport.static='f';
// SELECT DISTINCT typeid FROM swport JOIN boks USING(boksid) WHERE swport.static='t';

class getPortData
{
	public static final String navRoot = "/usr/local/nav/";
	public static final String configFile = "local/etc/conf/getPortData.conf";

	public static int NUM_THREADS = 16;
	public static final int SHOW_TOP = 25;

	public static final boolean ERROR_OUT = true;
	public static final boolean VERBOSE_OUT = false;
	public static final boolean DEBUG_OUT = false;

	public static final boolean DB_UPDATE = true;
	public static final boolean DB_COMMIT = true;

	// Felles datastrukturer som bare skal leses fra
	static HashMap macBoksId = new HashMap();
	static HashMap boksIdName = new HashMap();
	static HashMap boksidKat = new HashMap();
	static HashMap sysnameMap = new HashMap();

	// Swport
	static HashMap swportMap = new HashMap();
	static HashMap swportDataMap = new HashMap();

	static HashSet safeCloseBoksid = new HashSet();

	public static void main(String[] args) throws SQLException
	{
		ConfigParser cp;
		try {
			cp = new ConfigParser(navRoot + configFile);
		} catch (IOException e) {
			errl("Error, could not read config file: " + navRoot + configFile);
			return;
		}
		if (!Database.openConnection(cp.get("SQLServer"), cp.get("SQLDb"), cp.get("SQLUser"), cp.get("SQLPw"))) {
			errl("Error, could not connect to database!");
			return;
		}

		// Check arguments
		if (args.length > 0) {
			try {
				NUM_THREADS = Integer.parseInt(args[0]);
			} catch (NumberFormatException e) {
				outl("Error, unrecognized argument: " + args[0]);
				return;
			}
			if (NUM_THREADS > 128) {
				outl("Error, more than 128 threads not recommended, re-compile needed.");
				return;
			}
		}
		outl("Running with " + NUM_THREADS + " threads.");


		ResultSet rs;
		long dumpBeginTime,dumpUsedTime;

		outl("Dumping data from tables...");

		// Hent kobling mellom mac<->boksid og mac<->sysName
		//ResultSet rs = Database.query("SELECT mac,boksid,sysName FROM boksmac NATURAL JOIN boks");
		/*
		out("  boksmac_cache...");
		dumpBeginTime = System.currentTimeMillis();
		ResultSet rs = Database.query("SELECT mac,boksid FROM boksmac_cache");
		while (rs.next()) macBoksId.put(rs.getString("mac"), rs.getString("boksid"));
		dumpUsedTime = System.currentTimeMillis() - dumpBeginTime;
		outl(dumpUsedTime + " ms.");

		// Hent kobling mellom boksid<->sysName og motsatt
		out("  boks...");
		dumpBeginTime = System.currentTimeMillis();
		rs = Database.query("SELECT boksid,sysName,kat FROM boks");
		while (rs.next()) {
			boksIdName.put(rs.getString("boksid"), rs.getString("sysname"));
			boksidKat.put(rs.getString("boksid"), rs.getString("kat").toUpperCase());
			String sysname = rs.getString("sysname");
			String kat = rs.getString("kat").toLowerCase();
			if (kat.equals("gw") || kat.equals("sw") || kat.equals("kant")) {
				// Stripp etter f�rste '.'
				int i;
				if ( (i=sysname.indexOf('.')) != -1) {
					sysname = sysname.substring(0, i);
				}
			}
			sysnameMap.put(sysname, rs.getString("boksid"));
			//System.out.println("Lagt til: " + sysname + " kat: " + kat);
		}

		// Hent alle bokser der kat='GW'
		QueryBoks.boksGwSet = new HashSet();
		rs = Database.query("SELECT boksid FROM boks WHERE kat='GW'");
		while (rs.next()) {
			QueryBoks.boksGwSet.add(rs.getString("boksid"));
		}

		// Hent alle bokser av type 'cisco'
		rs = Database.query("SELECT boksid FROM boks NATURAL JOIN type WHERE lower(descr) LIKE '%cisco%'");
		while (rs.next()) {
			ciscoBoks.add(rs.getString("boksid"));
		}
		dumpUsedTime = System.currentTimeMillis() - dumpBeginTime;
		outl(dumpUsedTime + " ms.");
		*/

		// Hent kobling mellom boksid<->typegruppe
		out("  boks...");
		HashMap boksidTypegruppe = new HashMap();
		dumpBeginTime = System.currentTimeMillis();
		rs = Database.query("SELECT boksid,typegruppe FROM boks JOIN type USING (typeid)");
		while (rs.next()) {
			boksidTypegruppe.put(rs.getString("boksid"), rs.getString("typegruppe"));
		}
		dumpUsedTime = System.currentTimeMillis() - dumpBeginTime;
		outl(dumpUsedTime + " ms.");

		out("  swport...");
		dumpBeginTime = System.currentTimeMillis();
		//rs = Database.query("SELECT swportid,boksid,ifindex,modul,port,status,speed,duplex,media,trunk,portnavn FROM swport");
		rs = Database.query("SELECT swport.swportid,boksid,ifindex,modul,port,status,speed,duplex,media,trunk,portnavn,vlan FROM swport JOIN boks USING (boksid) LEFT JOIN swportvlan ON (trunk='f' AND swport.swportid=swportvlan.swportid) WHERE watch='f'");
		ResultSetMetaData rsmd = rs.getMetaData();
		while (rs.next()) {
			String key = rs.getString("boksid")+":"+rs.getString("ifindex");
			String swportid = rs.getString("swportid");
			swportMap.put(key, swportid);

			HashMap hm = getHashFromResultSet(rs, rsmd, true);
			swportDataMap.put(swportid, hm);
		}
		dumpUsedTime = System.currentTimeMillis() - dumpBeginTime;
		outl(dumpUsedTime + " ms.");

		/*
		// Vi trenger � vite alle boksid+ifindex som eksisterer i swport
		out("  swport...");
		dumpBeginTime = System.currentTimeMillis();
		rs = Database.query("SELECT DISTINCT ON (boksid,ifindex) swportid,boksid,ifindex FROM swport");
		while (rs.next()) {
			swportIfindex.put(rs.getString("boksid")+":"+rs.getString("ifindex"), rs.getString("swportid"));
		}
		*/

		// Denne inneholder alle "boksid:ifindex" fra swport som er trunk-porter
		/*
		QueryBoks.boksIfindexTrunkSet = new HashSet();
		rs = Database.query("SELECT boksid,ifindex FROM swport WHERE trunk='t'");
		while (rs.next()) {
			QueryBoks.boksIfindexTrunkSet.add(rs.getString("boksid")+":"+rs.getString("ifindex"));
		}
		*/

		/*
		// Mapping fra boksid, port og modul til swportid i swport
		QueryBoks.swportSwportidMap = new HashMap();
		rs = Database.query("SELECT swportid,boksid,modul,port FROM swport");
		while (rs.next()) {
			String key = rs.getString("boksid")+":"+rs.getString("modul")+":"+rs.getString("port");
			QueryBoks.swportSwportidMap.put(key, rs.getString("swportid"));
		}
		dumpUsedTime = System.currentTimeMillis() - dumpBeginTime;
		outl(dumpUsedTime + " ms.");

		// Hent alle vlan som er blokkert av spanning-tree
		out("  swportblocked...");
		dumpBeginTime = System.currentTimeMillis();
		rs = Database.query("SELECT swportid,boksid,ifindex,vlan FROM swportblocked NATURAL JOIN swport");
		while (rs.next()) {
			String key = rs.getString("boksid")+":"+rs.getString("vlan");
			HashMap blockedIfind;
			if (spanTreeBlocked.containsKey(key)) {
				blockedIfind = (HashMap)spanTreeBlocked.get(key);
			} else {
				blockedIfind = new HashMap();
				spanTreeBlocked.put(key, blockedIfind);
			}
			blockedIfind.put(rs.getString("ifindex"), rs.getString("swportid"));
		}
		dumpUsedTime = System.currentTimeMillis() - dumpBeginTime;
		outl(dumpUsedTime + " ms.");


		// Hent alle aktive vlan
		out("  vlan...");
		dumpBeginTime = System.currentTimeMillis();
		rs = Database.query("SELECT DISTINCT vlan FROM prefiks WHERE vlan IS NOT null");
		vlanList = new String[rs.getFetchSize()];
		for (int i=0; rs.next(); i++) vlanList[i] = rs.getString("vlan");
		dumpUsedTime = System.currentTimeMillis() - dumpBeginTime;
		outl(dumpUsedTime + " ms.");


		// Alt fra swp_boks for duplikatsjekking
		out("  swp_boks...");
		dumpBeginTime = System.currentTimeMillis();
		HashSet swp = new HashSet();
		HashMap swp_d = new HashMap();
		rs = Database.query("SELECT swp_boksid,boksid,modul,port,boksbak FROM swp_boks");
		//rs = Database.query("SELECT swp_boksid,boksid,modul,port,boksbak FROM swp_boks JOIN boks USING (boksid) WHERE sysName='sb-sw'");
		while (rs.next()) {
			String key = rs.getString("boksid")+":"+rs.getString("modul")+":"+rs.getString("port")+":"+rs.getString("boksbak");
			String[] val = { rs.getString("swp_boksid"), rs.getString("boksid"), rs.getString("modul"), rs.getString("port"), rs.getString("boksbak") };
			swp.add(key);
			swp_d.put(key, val);
		}
		dumpUsedTime = System.currentTimeMillis() - dumpBeginTime;
		outl(dumpUsedTime + " ms.");

		// For CAM-logger, alle uavsluttede CAM-records (dvs. alle steder hvor til er null)
		out("  cam...");
		dumpBeginTime = System.currentTimeMillis();
		rs = Database.query("SELECT camid,boksid,modul,port,mac FROM cam WHERE til = 'infinity'");
		while (rs.next()) {
			String key = rs.getString("boksid")+":"+rs.getString("modul")+":"+rs.getString("port")+":"+rs.getString("mac");
			unclosedCam.put(key, rs.getString("camid"));
		}
		dumpUsedTime = System.currentTimeMillis() - dumpBeginTime;
		outl(dumpUsedTime + " ms.");
		*/


		String qNettel;

		//qNettel = "_all";
		//qNettel = "_new";
		//qNettel = "_sw";
		//qNettel = "_gw";
		//qNettel = "_kant";
		//qNettel = "_cat-ios";
		//qNettel = "_cdp";
		//qNettel = "voll-sw";
		//qNettel = "sb-353-sw";
		//qNettel = "hyper-sw";
		//qNettel = "voll-sby-981-h";
		//qNettel = "hb-301-sw2";
		//qNettel = "_3com";
		//qNettel = "voll-sw";
		//qNettel = "voll-sby-982-h2";
		//qNettel  = "_voll";
		qNettel = "_def";

		Database.setDefaultKeepOpen(true);
		if (qNettel.equals("_new")) {
			rs = Database.query("SELECT ip,ro,boksid,typeid,typegruppe,kat,sysName FROM boks NATURAL JOIN type WHERE NOT EXISTS (SELECT boksid FROM swp_boks WHERE boksid=boks.boksid) AND (kat='KANT' or kat='SW') ORDER BY boksid");
		} else
		if (qNettel.equals("_all")) {
			rs = Database.query("SELECT ip,ro,boksid,typeid,typegruppe,kat,sysName FROM boks NATURAL JOIN type WHERE (kat='SW' OR kat='KANT' OR kat='GW') AND watch='f'");
		} else
		if (qNettel.equals("_gw")) {
			rs = Database.query("SELECT ip,ro,boksid,typeid,typegruppe,kat,sysName FROM boks NATURAL JOIN type WHERE kat='GW'");
		} else
		if (qNettel.equals("_sw")) {
			rs = Database.query("SELECT ip,ro,boksid,typeid,typegruppe,kat,sysName FROM boks NATURAL JOIN type WHERE kat='SW'");
		} else
		if (qNettel.equals("_kant")) {
			rs = Database.query("SELECT ip,ro,boksid,typeid,typegruppe,kat,sysName FROM boks NATURAL JOIN type WHERE kat='KANT'");
		} else
		if (qNettel.equals("_3com")) {
			rs = Database.query("SELECT ip,ro,boksid,typeid,typegruppe,kat,sysName FROM boks NATURAL JOIN type WHERE typegruppe like '3%' AND watch='f'");
		} else
		if (qNettel.equals("_voll")) {
			rs = Database.query("SELECT ip,ro,boksid,typeid,typegruppe,kat,sysName FROM boks NATURAL JOIN type WHERE sysname like 'voll%'");
		} else
		if (qNettel.equals("_def")) {
			// USE THIS
			//rs = Database.query("SELECT ip,ro,boksid,typeid,typegruppe,kat,sysName FROM boks NATURAL JOIN type WHERE watch='f' AND (typegruppe LIKE '3%' OR typeid LIKE 'C3000%' OR typeid LIKE 'C1900%')");
			rs = Database.query("SELECT ip,ro,boksid,typeid,typegruppe,kat,sysName FROM boks NATURAL JOIN type WHERE watch='f' AND boksid NOT IN (278) AND (typegruppe LIKE '3%' OR typegruppe IN ('catmeny-sw', 'cat1900-sw') )");
			//rs = Database.query("SELECT ip,ro,boksid,typeid,typegruppe,kat,sysName FROM boks NATURAL JOIN type WHERE boksid=755");
		} else {
			rs = Database.query("SELECT ip,ro,boksid,typeid,typegruppe,kat,sysName FROM boks NATURAL JOIN type WHERE sysName='"+qNettel+"'");
		}
		Database.setDefaultKeepOpen(false);

		Stack bdStack = new Stack();
		while (rs.next()) {
			BoksData bd = new BoksData();
			bd.ip = rs.getString("ip");
			bd.cs_ro = rs.getString("ro");
			bd.boksId = rs.getString("boksid");
			bd.boksTypegruppe = rs.getString("typegruppe");
			bd.boksType = rs.getString("typeid");
			bd.sysName = rs.getString("sysname");
			bd.kat = rs.getString("kat");
			//bd.vekt = vekt;
			bdStack.push(bd);
		}
		int antBd = bdStack.size();

		// Sett datastrukturer for alle tr�der
		QueryBoks.ERROR_OUT = ERROR_OUT;
		QueryBoks.VERBOSE_OUT = VERBOSE_OUT;
		QueryBoks.DEBUG_OUT = DEBUG_OUT;
		QueryBoks.DB_UPDATE = DB_UPDATE;
		QueryBoks.DB_COMMIT = DB_COMMIT;

		/*
		QueryBoks.macBoksId = macBoksId;
		QueryBoks.boksIdName = boksIdName;
		QueryBoks.boksidKat = boksidKat;
		QueryBoks.sysnameMap = sysnameMap;
		*/
		QueryBoks.setSwportMap(swportMap);
		QueryBoks.setSwportDataMap(swportDataMap);
		QueryBoks.setSafeCloseBoksid(safeCloseBoksid);

		// Indikerer om en tr�d er ferdig
		QueryBoks.initThreadDone(NUM_THREADS);

		// Lag tr�dene
		long beginTime = System.currentTimeMillis();
		Thread[] threads = new Thread[NUM_THREADS];
		int digits = String.valueOf(NUM_THREADS-1).length();
		for (int i=0; i < NUM_THREADS; i++) {
			threads[i] = new QueryBoks(i, format(i, digits), bdStack, antBd);
			threads[i].start();
		}

		for (int i=0; i < NUM_THREADS; i++) {
			try {
				threads[i].join();
			} catch (InterruptedException e) {
				errl("Error, got InterruptedException: " + e.getMessage() );
			}
		}
		long usedTime = System.currentTimeMillis() - beginTime;

		// Sjekk om det er port-innslag som ikke lenger er tilstedet
		Iterator iter = swportDataMap.values().iterator();
		int remcnt=0;
		while (iter.hasNext()) {
			HashMap hm = (HashMap)iter.next();
			String boksid = (String)hm.get("boksid");
			if (!safeCloseBoksid.contains(boksid)) continue;

			String typegruppe = (String)boksidTypegruppe.get(boksid);

			if (typegruppe.startsWith("3") || typegruppe.equals("catmeny-sw") || typegruppe.equals("cat1900-sw")) {
				// Slett enheten
				remcnt++;
				//System.err.println("Want to delete: " + hm.get("boksid") + " Modul: " + hm.get("modul") + " Port: " + hm.get("port") + " Vlan: " + hm.get("vlan"));

			}

		}
		outl("Missing data from " + remcnt + " ports");

		// Lag rapport p� tid brukt p� de forskjellige boksene
		ArrayList boksReport = QueryBoks.boksReport;
		Collections.sort(boksReport);

		digits = String.valueOf(Math.min(SHOW_TOP, boksReport.size())).length();
		for (int i=0; i < SHOW_TOP && i < boksReport.size(); i++) {
			BoksReport br = (BoksReport)boksReport.get(i);
			outl(format(i+1, digits)+": " + formatTime(br.getUsedTime()) + ", " + br.getBoksData().sysName + " (" + br.getBoksData().boksType + ") (" + br.getBoksData().ip + ")");
		}

		Database.closeConnection();
		outl("All done, time used: " + formatTime(usedTime) + ".");

		// Create a job-finished file
		try {
			String curDir = System.getProperty("user.dir");
			char sep = File.separatorChar;
			File f = new File(curDir+sep+"job-finished");
			f.createNewFile() ;
		} catch (SecurityException e) {
			errl("Error, cannot write to user.dir: " + e.getMessage() );
		} catch (IOException e) {
			errl("Error, got IOException: " + e.getMessage() );
		}

		outflush();
		errflush();
		System.exit(0);


	}

	private static String format(long i, int n)
	{
		DecimalFormat nf = new DecimalFormat("#");
		nf.setMinimumIntegerDigits(n);
		return nf.format(i);
	}

	public static String formatTime(long t)
	{
		long h = t / (60 * 60 * 1000);
		t %= 60 * 60 * 1000;

		long m = t / (60 * 1000);
		t %= 60 * 1000;

		long s = t / (1000);
		t %= 1000;

		long ms = t;

		return format(h,2)+":"+format(m,2)+":"+format(s,2)+"."+format(ms,3);
	}
	private static HashMap getHashFromResultSet(ResultSet rs, ResultSetMetaData md, boolean convertNull) throws SQLException {
		HashMap hm = new HashMap();
		for (int i=md.getColumnCount(); i > 0; i--) {
			String val = rs.getString(i);
			hm.put(md.getColumnName(i), (convertNull&&val==null)?"":val);
		}
		return hm;
	}

	private static void out(Object o) { System.out.print(o); }
	private static void outl(Object o) { System.out.println(o); }
	private static void outflush() { System.out.flush(); }
	private static void err(Object o) { System.err.print(o); }
	private static void errl(Object o) { System.err.println(o); }
	private static void errflush() { System.err.flush(); }

}

class QueryBoks extends Thread
{
	public static boolean ERROR_OUT = true;
	public static boolean VERBOSE_OUT = false;
	public static boolean DEBUG_OUT = false;
	public static boolean DB_UPDATE = false;
	public static boolean DB_COMMIT = false;

	// Felles datastrukturer som bare skal leses fra
	/*
	public static HashMap macBoksId;
	public static HashMap boksIdName;
	public static HashMap boksidKat;
	public static HashMap sysnameMap;
	*/

	static HashMap swportMap;
	public static void setSwportMap(HashMap h) { swportMap=h; }
	static HashMap swportDataMap;
	public static void setSwportDataMap(HashMap h) { swportDataMap=h; }

	static HashSet safeCloseBoksid;
	public static void setSafeCloseBoksid(HashSet h) { safeCloseBoksid=h; }

	// K�en som inneholder alle boksene, delt mellom tr�dene
	Stack bdStack;
	// Hvilke tr�der som er ferdig
	static boolean[] threadDone;

	// Rapport n�r en boks er ferdigbehandlet
	static ArrayList boksReport = new ArrayList();

	// Objekt-spesifikke data
	int num;
	String id;
	int antBd;

	SimpleSnmp sSnmp = new SimpleSnmp();

	// Konstrukt�r
	public QueryBoks(int num, String id, Stack bdStack, int antBd)
	{
		this.num = num;
		this.id = id;
		this.bdStack = bdStack;
		this.antBd = antBd;
	}

	public static void initThreadDone(final int NUM_THREADS)
	{
		threadDone = new boolean[NUM_THREADS];
		for (int i=0; i < threadDone.length; i++) {
			threadDone[i] = false;
		}
	}


	private static String[] modulNameShorts = {
		"FastEthernet", "Fa",
		"GigabitEthernet", "Gi"
	};
	private static String processModulName(String modul)
	{
		for (int j=0; j<modulNameShorts.length; j+=2) {
			if (modul.startsWith(modulNameShorts[j])) modul = modulNameShorts[j+1]+modul.substring(modulNameShorts[j].length(), modul.length());
		}
		return modul;
	}


	public void run()
	{
		long beginTime = System.currentTimeMillis();

		while (true) {
			BoksData bd;
			int bdRemaining;
			synchronized (bdStack) {
				if (!bdStack.empty()) {
					bd = (BoksData)bdStack.pop();
					bdRemaining = bdStack.size();
				} else {
					// Stack er tom, alts� er vi ferdig
					break;
				}
			}

			String ip = bd.ip;
			String cs_ro = bd.cs_ro;
			String boksId = bd.boksId;
			String boksTypegruppe = bd.boksTypegruppe;
			String boksType = bd.boksType;
			String sysName = bd.sysName;
			String kat = bd.kat;

			outla("T"+id+": Now working with("+boksId+"): " + sysName + " ("+ boksType +") ("+ ip +") ("+ bdRemaining +" of "+ antBd+" left)");
			long boksBeginTime = System.currentTimeMillis();

			// Liste over alle innslagene vi evt. skal sette inn i swp_boks
			//ArrayList boksListe = new ArrayList();

			// OK, pr�v � sp�rre
			int newcnt=0,updcnt=0,remcnt=0;
			try {
				// Hvis dette er Cisco utstyr trenger vi ifindexMp kobling
				HashMap ifindexMp = null;
				if (boksTypegruppe.equals("cgw-nomem") ||
					boksTypegruppe.equals("cgw") ||
					boksTypegruppe.equals("ios-sw") ||
					boksTypegruppe.equals("cat-sw") ) {

					continue; // Skal ikke jobbe med disse Cisco enda

				} else
				if (boksTypegruppe.equals("cat1900-sw") ||
					boksTypegruppe.equals("catmeny-sw") ) {
					ifindexMp = fetchIfindexMpMap(ip, cs_ro, boksTypegruppe);
					//boolean decodeHex = false;
				}

				if (kat.equals("GW")) {

					long boksUsedTime = System.currentTimeMillis() - boksBeginTime;
					synchronized (boksReport) {
						boksReport.add(new BoksReport((int)boksUsedTime, bd));
					}
					continue;
				}

				ArrayList portDataList = new ArrayList();

				if (boksTypegruppe.equals("cat1900-sw")) {
					portDataList = processCisco1900(boksId, ip, cs_ro, boksType, ifindexMp);
				} else
				if (boksTypegruppe.equals("catmeny-sw")) {
					portDataList = processCisco1Q(boksId, ip, cs_ro, boksType);
				} else
				/*
				if (boksTypegruppe.equals("cat-sw") || boksTypegruppe.equals("ios-sw")) {
					// Cisco utstyr der man m� hente per vlan
					macListe = processCisco2Q(boksId, ip, cs_ro, boksTypegruppe, boksType, ifindexMp);
				} else
				*/
				if (boksTypegruppe.equals("3hub") || boksTypegruppe.equals("3ss") || boksTypegruppe.equals("3ss9300")) {
					// Alt 3Com utstyr
					portDataList = process3Com(boksId, ip, cs_ro, boksTypegruppe, boksType);
				} else {
					outle("  Error, unknown/unsupported typegruppe: " + boksTypegruppe);
				}

				if (!sSnmp.resetGotTimeout() && !portDataList.isEmpty()) synchronized (safeCloseBoksid) { safeCloseBoksid.add(boksId); }

				Collections.sort(portDataList); // Egentlig un�dvendig, men kjekt � ha det ferdig sortert i databasen
				for (int i=0; i < portDataList.size(); i++) {
					PortData pd = (PortData)portDataList.get(i);

					// OK, f�rst sjekk om denne porten er i swport fra f�r
					String key = boksId+":"+pd.getIfindex();
					String swportid = (String)swportMap.remove(key);

					if (swportid == null) {
						// Ikke fra f�r, vi m� sette inn
						String[] insertFields = {
							"boksid", boksId,
							"ifindex", pd.getIfindex(),
							"modul", pd.getModul(),
							"port", pd.getPort(),
							"status", pd.getStatus(),
							"speed", pd.getSpeed(),
							"duplex", pd.getDuplex(),
							"media", pd.getMedia(),
							"trunk", pd.getTrunkS(),
							"portnavn", Database.addSlashes(pd.getPortnavn())
						};
						if (DB_UPDATE) {
							String sql = "INSERT INTO swportvlan (swportid,vlan) VALUES ((SELECT swportid FROM swport WHERE boksid='"+boksId+"' AND ifindex='"+pd.getIfindex()+"'),'"+pd.getVlan()+"')";
							try {
								newcnt += Database.insert("swport", insertFields);

								if (!pd.getTrunk()) {
									// Sett inn i swportvlan ogs�
									Database.update(sql);
								}

								if (DEBUG_OUT) outl("Inserted row: " + pd);
								if (DB_COMMIT) Database.commit(); else Database.rollback();
							} catch (SQLException e) {
								outle("  SQLException in QueryBoks.run(): Cannot insert new record into swport/swportvlan: " + e.getMessage());
								outle("  SQL: " + sql);
							}
						}

					} else {
						// Eksisterer fra f�r, da skal vi evt. oppdatere hvis n�dvendig
						boolean needUpdate = true;
						HashMap hm;
						synchronized (swportDataMap) {
							// Ta saken ut fra listen, skal ikke slettes
							hm = (HashMap)swportDataMap.remove(swportid);
						}
						if (hm == null) {
							outle("  Error in QueryBoks.run(): Should not happen, swportDataMap not found for swportid: " + swportid);
							continue;
						}

						/*
						String[] tt = {
							"boksid",
							"ifindex",
							"modul",
							"port",
							"status",
							"speed",
							"duplex",
							"media",
							"trunk",
							"portnavn"
						};
						for (int j=0;j<tt.length; j++) {
							if (!hm.containsKey(tt[j]) || hm.get(tt[j]) == null) {
								outle("tt: " + tt[j] + " key: " + hm.containsKey(tt[j]) + " val: " + hm.get(tt[j]));
								outle(pd);
							}
						}
						*/

						//outle("boksid: " + hm.containsKey("boksid") + " val: " + hm.get("boksid") );
						//outle("ifindex: " + hm.containsKey("ifindex") + " val: "+ hm.get("ifindex") );
						//outle("modul: " + hm.containsKey("modul") + " val: "+ hm.get("modul") );

						//System.err.println("swportid: " + swportid + " oldVlan: " + hm.get("vlan") + " newVlan: " + pd.getVlan());

						// M� ikke v�re null p� grunn av sjekkingen her
						if (hm.get("vlan") == null) hm.put("vlan", "");

						if (hm.get("boksid").equals(boksId) &&
							hm.get("ifindex").equals(pd.getIfindex() ) &&
							hm.get("modul").equals(pd.getModul() ) &&
							hm.get("port").equals(pd.getPort() ) &&
							hm.get("status").equals(pd.getStatus() ) &&
							hm.get("speed").equals(pd.getSpeed() ) &&
							hm.get("duplex").equals(pd.getDuplex() ) &&
							hm.get("media").equals(pd.getMedia() ) &&
							hm.get("trunk").equals(pd.getTrunkS() ) &&
							hm.get("portnavn").equals(pd.getPortnavn() ) &&
							hm.get("vlan").equals(String.valueOf(pd.getVlan()) )) {

							needUpdate = false;
						}
						if (needUpdate) {
							String[] updateFields = {
								"boksid", boksId,
								"ifindex", pd.getIfindex(),
								"modul", pd.getModul(),
								"port", pd.getPort(),
								"status", pd.getStatus(),
								"speed", pd.getSpeed(),
								"duplex", pd.getDuplex(),
								"media", pd.getMedia(),
								"trunk", pd.getTrunkS(),
								"portnavn", Database.addSlashes(pd.getPortnavn())
							};
							String[] condFields = {
								"swportid", swportid
							};
							if (DB_UPDATE) {
								try {
									updcnt += Database.update("swport", updateFields, condFields);

									if (!pd.getTrunk()) {
										// Ogs� oppdater swportvlan
										if (((String)hm.get("vlan")).length() == 0) {
											// M� sette inn ny record
											//outle("T"+id+":   "+ "INSERT INTO swportvlan (swportid,vlan) VALUES ('"+swportid+"','"+pd.getVlan()+"')");
											Database.update("INSERT INTO swportvlan (swportid,vlan) VALUES ('"+swportid+"','"+pd.getVlan()+"')");
										} else {
											//outle("T"+id+":   "+ "UPDATE swportvlan SET vlan = '"+pd.getVlan()+"' WHERE swportid = '"+swportid+"'");
											Database.update("UPDATE swportvlan SET vlan = '"+pd.getVlan()+"' WHERE swportid = '"+swportid+"'");
										}
									}

									if (DEBUG_OUT) outl("Updated row: " + pd);
									if (DB_COMMIT) Database.commit(); else Database.rollback();
								} catch (SQLException e) {
									outle("T"+id+":   SQLException in QueryBoks.run(): Cannot update record from swport: " + e.getMessage());
									//outle("T"+id+":     swportid: " + swportid + " oldVlan: " + hm.get("vlan") + " newVlan: " + pd.getVlan());
								}
							}
						}




					}
				}


			//} catch (SQLException se) {
			//	outld("*ERROR* SQLException: " + se.getMessage());
			} catch (TimeoutException te) {
				outl("T"+id+":   *ERROR*, TimeoutException: " + te.getMessage());
				outla("T"+id+":   *** GIVING UP ON: " + sysName + ", typeid: " + boksType + " ***");
				continue;
			}

			/*
			int newCnt=0,dupCnt=0;
			for (int i=0; i < boksListe.size(); i++) {
			*/


			if (newcnt > 0 || updcnt > 0) {
				outl("T"+id+": Inserted a total of " + newcnt + " new rows, " + updcnt + " updated rows.");
			}

			long boksUsedTime = System.currentTimeMillis() - boksBeginTime;
			synchronized (boksReport) {
				boksReport.add(new BoksReport((int)boksUsedTime, bd));
			}
		}
		long usedTime = System.currentTimeMillis() - beginTime;
		threadDone[num] = true;
		outla("T"+id+": ** Thread done, time used: " + getPortData.formatTime(usedTime) + ", waiting for " + getThreadsNotDone() + " **");

	}

	private String getThreadsNotDone()
	{
		StringBuffer sb = new StringBuffer();
		int startRange=0;
		boolean markLast=false;

		for (int i=0; i < threadDone.length+1; i++) {
			if (i != threadDone.length && !threadDone[i]) {
				if (!markLast) {
					startRange=i;
					markLast = true;
				}
			} else if (markLast) {
				String range = (startRange==i-1) ? String.valueOf(i-1) : startRange+"-"+(i-1);
				sb.append(","+range);
				markLast=false;
			}
		}
		if (sb.length() > 0) {
			sb.setCharAt(0, '[');
		} else {
			sb.insert(0, "[");
		}
		sb.append("]");
		return sb.toString();
	}


	/*
	 * Cisco MAC
	 *
	 */
	private ArrayList processCisco1900(String boksid, String ip, String cs_ro, String boksType, HashMap ifindexMp) throws TimeoutException
	{
		ArrayList l = new ArrayList();

		// Modul er alltid 1 p� denne typen enhet
		String modul = "1";

		/*
		Alle C1900*

	ifindex:
		1.3.6.1.2.1.2.2.1.1 = ifindex
		port = ifindex

	Status:
		1.3.6.1.2.1.2.2.1.8 = status

		1 = up
		2/other = down

	Speed:
		1.3.6.1.2.1.2.2.1.5 = speed

		speed is in bits/sec

	Duplex:
		1.3.6.1.4.1.437.1.1.3.3.1.1.8 = duplex

		1 = full
		2 = half

	Portnavn:
		1.3.6.1.4.1.437.1.1.3.3.1.1.3 = portnavn

		FIXME: Mangler info om media. Bruker vlan=1 p� alle porter

		*/

		String ifindexOid = "1.3.6.1.2.1.2.2.1.1";
		String statusOid = "1.3.6.1.2.1.2.2.1.8";
		String speedOid = "1.3.6.1.2.1.2.2.1.5";
		String duplexOid = "1.3.6.1.4.1.437.1.1.3.3.1.1.8";
		String portnavnOid = "1.3.6.1.4.1.437.1.1.3.3.1.1.3";

		// Start med � hente alle ifindex/porter
		sSnmp.setParams(ip, cs_ro, ifindexOid);
		ArrayList portList = sSnmp.getAll();

		HashMap portMap = new HashMap();
		for (int i=0; i < portList.size(); i++) {
			String[] s = (String[])portList.get(i);

			String ifindex = getLastToken(s[0]);
			String port = s[1];
			PortData pd = new PortData(ifindex, modul, port);
			portMap.put(ifindex, pd);
		}

		// Hent status
		sSnmp.setParams(ip, cs_ro, statusOid);
		portList = sSnmp.getAll();
		for (int i=0; i < portList.size(); i++) {
			String[] s = (String[])portList.get(i);
			String ifindex = getLastToken(s[0]);
			PortData pd = (PortData)portMap.get(ifindex);

			String status = (s[1].equals("1") ? "up" : "down");
			pd.setStatus(status);
		}

		// Hent speed&media
		sSnmp.setParams(ip, cs_ro, speedOid);
		portList = sSnmp.getAll();
		for (int i=0; i < portList.size(); i++) {
			String[] s = (String[])portList.get(i);
			String ifindex = getLastToken(s[0]);
			PortData pd = (PortData)portMap.get(ifindex);

			long speed = Long.parseLong(s[1]);
			speed /= 1000000; // Speed is in Mbit/sec

			pd.setSpeed(String.valueOf(speed));
		}

		// Hent duplex
		sSnmp.setParams(ip, cs_ro, duplexOid);
		portList = sSnmp.getAll();
		for (int i=0; i < portList.size(); i++) {
			String[] s = (String[])portList.get(i);
			String ifindex = getLastToken(s[0]);
			PortData pd = (PortData)portMap.get(ifindex);

			String duplex = (s[1].equals("1") ? "full" : "half");
			pd.setDuplex(duplex);
		}

		// Hent portnavn
		sSnmp.setParams(ip, cs_ro, portnavnOid);
		portList = sSnmp.getAll(true);
		for (int i=0; i < portList.size(); i++) {
			String[] s = (String[])portList.get(i);
			String ifindex = getLastToken(s[0]);
			PortData pd = (PortData)portMap.get(ifindex);

			pd.setPortnavn(s[1].trim());
		}

		Iterator iter = portMap.values().iterator();
		while (iter.hasNext()) {
			PortData pd = (PortData)iter.next();
			l.add(pd);
		}

		return l;
	}

	private ArrayList processCisco1Q(String boksid, String ip, String cs_ro, String boksType) throws TimeoutException
	{
		ArrayList l = new ArrayList();

		// Modul er alltid 1 p� denne typen enhet
		String modul = "1";

		/*
		St�tter C3000/C3100

	ifindex:
		1.3.6.1.4.1.9.5.14.4.1.1.4 = ifindex
		port = ifindex

	Status:
		1.3.6.1.4.1.9.5.14.4.1.1.29 = status

		1 = up
		2/other = down

	Speed & Media:
		1.3.6.1.4.1.9.5.14.4.1.1.41 = value

		speed = 10 if value in [1,5,6,7]
		speed = 100 if value in [3,4,10,11,12,13]

		value=1  => media = 10BaseT
		value=3  => media = 100BaseT
		value=4  => media = 100BaseFX
		value=7  => media = 10BaseFL
		value=12 => media = ISL FX
		value=13 => media = ISL TX

	Duplex:
		1.3.6.1.4.1.9.5.14.4.1.1.5 = duplex

		1 = full
		2 = half

	Trunk:
		1.3.6.1.4.1.9.5.14.4.1.1.44 = value

		trunking if value = 1
		non-trunking if value = 2

		*/
		String ifindexOid = "1.3.6.1.4.1.9.5.14.4.1.1.4";
		String statusOid = "1.3.6.1.4.1.9.5.14.4.1.1.29";
		String speedOid = "1.3.6.1.4.1.9.5.14.4.1.1.41";
		String duplexOid = "1.3.6.1.4.1.9.5.14.4.1.1.5";
		String trunkOid = "1.3.6.1.4.1.9.5.14.4.1.1.44";

		// Start med � hente alle ifindex/porter
		sSnmp.setParams(ip, cs_ro, ifindexOid);
		ArrayList portList = sSnmp.getAll();

		HashMap portMap = new HashMap();
		for (int i=0; i < portList.size(); i++) {
			String[] s = (String[])portList.get(i);

			String ifindex = getLastToken(s[0]);
			String port = s[1];
			PortData pd = new PortData(ifindex, modul, port);
			portMap.put(ifindex, pd);
		}

		// Hent status
		sSnmp.setParams(ip, cs_ro, statusOid);
		portList = sSnmp.getAll();
		for (int i=0; i < portList.size(); i++) {
			String[] s = (String[])portList.get(i);
			String ifindex = getLastToken(s[0]);
			PortData pd = (PortData)portMap.get(ifindex);

			String status = (s[1].equals("1") ? "up" : "down");
			pd.setStatus(status);
		}

		// Hent speed&media
		sSnmp.setParams(ip, cs_ro, speedOid);
		portList = sSnmp.getAll();
		for (int i=0; i < portList.size(); i++) {
			String[] s = (String[])portList.get(i);
			String ifindex = getLastToken(s[0]);
			PortData pd = (PortData)portMap.get(ifindex);

			String speed = "-1";
			if (s[1].equals("1") || s[1].equals("5") || s[1].equals("6") || s[1].equals("7")) {
				speed = "10";
			} else
			if (s[1].equals("3") || s[1].equals("4") || s[1].equals("10") || s[1].equals("11") || s[1].equals("12") || s[1].equals("13")) {
				speed = "100";
			}

			String media = "Unknown";
			if (s[1].equals("1")) media = "10Base-T";
			if (s[1].equals("3")) media = "100Base-T";
			if (s[1].equals("4")) media = "100Base-FX";
			if (s[1].equals("7")) media = "10Base-FL";
			if (s[1].equals("12")) media = "ISL FX";
			if (s[1].equals("13")) media = "ISL TX";

			pd.setSpeed(speed);
			pd.setMedia(media);
		}

		// Hent duplex
		sSnmp.setParams(ip, cs_ro, duplexOid);
		portList = sSnmp.getAll();
		for (int i=0; i < portList.size(); i++) {
			String[] s = (String[])portList.get(i);
			String ifindex = getLastToken(s[0]);
			PortData pd = (PortData)portMap.get(ifindex);

			String duplex = (s[1].equals("1") ? "full" : "half");
			pd.setDuplex(duplex);
		}

		// Hent trunk
		sSnmp.setParams(ip, cs_ro, trunkOid);
		portList = sSnmp.getAll();
		for (int i=0; i < portList.size(); i++) {
			String[] s = (String[])portList.get(i);
			String ifindex = getLastToken(s[0]);
			PortData pd = (PortData)portMap.get(ifindex);

			boolean trunk = s[1].equals("1");
			pd.setTrunk(trunk);
		}

		Iterator iter = portMap.values().iterator();
		while (iter.hasNext()) {
			PortData pd = (PortData)iter.next();
			l.add(pd);
		}

		return l;
	}
	private String getLastToken(String s)
	{
		char sep = '.';
		int i;
		if ( (i=s.lastIndexOf(sep)) == -1) return s;

		return s.substring(i+1, s.length()).trim();
	}

	private ArrayList processCisco2Q(String boksid, String ip, String cs_ro, String typegruppe, String boksType, HashMap ifindexMp) throws TimeoutException
	{
		ArrayList l = new ArrayList();
		String ciscoIndexMapBaseOid = ".1.3.6.1.2.1.17.1.4.1.2";
		String ciscoMacBaseOid = ".1.3.6.1.2.1.17.4.3.1.2";
		String spanningTreeOid = ".1.3.6.1.2.1.17.2.15.1.3";

		return l;
	}

	private HashMap fetchIfindexMpMap(String ip, String cs_ro, String typegruppe) throws TimeoutException
	{
		//String ciscoIndexMapBaseOid = ".1.3.6.1.2.1.17.1.4.1.2";

		// Hent kobling mellom ifIndex<->mp
		HashMap ifindexH = new HashMap();
		String ifmpBaseOid = "";
		if (typegruppe.equals("cat-sw")) {
			ifmpBaseOid = ".1.3.6.1.4.1.9.5.1.4.1.1.11";

			//ArrayList ifmpList = getOIDs(ip, cs_ro, ifmpBaseOid);
			sSnmp.setParams(ip, cs_ro, ifmpBaseOid);
			ArrayList ifmpList = sSnmp.getAll(true);

			outl("  Found " + ifmpList.size() + " ifindex<->mp mappings.");
			for (int i=0; i < ifmpList.size(); i++) {
				String[] s = (String[])ifmpList.get(i);
				StringTokenizer st = new StringTokenizer(s[0], ".");
				String[] mp = { st.nextToken(), st.nextToken() };
				ifindexH.put(s[1], mp);
				//outl("Add Modul: " + mp[0] + " Port: " + mp[1] + " ifIndex: " + s[1]);
			}

		} else
		if (typegruppe.equals("ios-sw") ||
			typegruppe.equals("cgw") ||
			typegruppe.equals("cgw-nomem") ||
			typegruppe.equals("cat1900-sw") ) {

			ifmpBaseOid = ".1.3.6.1.2.1.2.2.1.2";
			//ArrayList ifmpList = getOIDs(ip, cs_ro, ifmpBaseOid);
			sSnmp.setParams(ip, cs_ro, ifmpBaseOid);
			ArrayList ifmpList = sSnmp.getAll(true);

			outl("  Found " + ifmpList.size() + " ifindex<->mp mappings.");
			for (int i=0; i < ifmpList.size(); i++) {
				String[] s = (String[])ifmpList.get(i);
				StringTokenizer st = new StringTokenizer(s[1], "/");
				String modul = st.nextToken();
				String port = (st.hasMoreTokens()) ? st.nextToken() : "";

				// Hvis modul inneholder f.eks FastEther0 skal dette forkortes til Fa0
				modul = processModulName(modul);

				if (port.length() == 0) {
					port = modul;
					modul = "1";

					try {
						Integer.parseInt(port);
					} catch (NumberFormatException e) {
						port = s[0];
					}
				}

				String[] mp = { modul, port };
				//if (mp[1].length() == 0) mp[1] = "1";

				ifindexH.put(s[0], mp);
				//outl("Add Modul: " + mp[0] + " Port: " + mp[1] + " ifIndex: " + s[0]);
			}

		} else {
			outl("  *ERROR*! Unknown typegruppe: " + typegruppe);
			//return ifindexH;
		}
		return ifindexH;
	}

	/*
	 * 3COM
	 *
	 */
	private ArrayList process3Com(String boksid, String ip, String cs_ro, String typegruppe, String typeid) throws TimeoutException
	{
		ArrayList l = new ArrayList();
		typeid = typeid.toLowerCase();

		/*
		PS40:
		=====
		Kan finne oppe/nede med .1.3.6.1.2.1.26.1.1.1.6.<unit>.<port>.1 = 3|4
		3 = oppe
		4 = nede

		Synes man her skal lage en ifindex av typen
		 unit1port15 har ifindex 115
		speed og duplex: for ps40 har vi jo bare halv duplex, speed 10, forutsatt
		 at porten er oppe.

		SWxx00
		======
	IfIndex:
		Tolkes fra ifDescr:
		.1.3.6.1.2.1.2.2.1.2.ifindex = tekststring av litt diverse typer. M�
		plukke ut de som inneholder ordene 'unit' og 'port'. Tungvint, men har
		ikke noe bedre :(

		SW9300: SuperStack II Switch 9300, manuf: 3Com, Gigabit-Ethernet Port 1
		SW3300: RMON:10/100 Port 13 on Unit 4
		SW1100: RMON:V2 Port 1 on Unit 2

	Speed & Duplex
		kan finnes fra ifMauType:
		.1.3.6.1.2.1.26.2.1.1.3.ifindex.1 = oid

		SW9300: N/A
		SW3300: 26.4.16 / enterprises.43.18.8.2.3
		SW1100: 26.4.10

		26.4.10: 10BaseTHD     10 HD
		26.4.11: 10BaseTFD     10 FD
		26.4.15: 100BaseTXHD  100 HD
		26.4.16: 100BaseTXFD  100 FD
		26.4.17: 100BaseFXHD  100 HD
		26.4.18: 100BaseFXFD  100 FD
		enterprises.43.18.8.2.3: 1000 FD TP
		enterprises.43.18.8.2.7: 1000 FD Fiber SX

	Speed:
		.1.3.6.1.2.1.2.2.1.5

		SW9300: Gauge32: 1000000000

	Up/down:
		.1.3.6.1.2.1.2.2.1.8

		SW9300:
		1 = up
		2 = down

		*/


		if (typeid.equals("off8") || typeid.equals("ps40")) {
			// OID: 1.3.6.1.2.1.26.1.1.1.6.<modul>.<port>.1 = 3|4
			// 3 = oppe
			// 4 = nede
			// IfIndex = <modul><port>
			String speed = "10";
			String duplex = "half";
			String media = "10Base-T";

			// Hent listen
			String baseOid = "1.3.6.1.2.1.26.1.1.1.6";
			sSnmp.setParams(ip, cs_ro, baseOid);
			ArrayList portList = sSnmp.getAll();

			for (int i=0; i < portList.size(); i++) {
				String[] s = (String[])portList.get(i);
				StringTokenizer st = new StringTokenizer(s[0], ".");
				String modul = st.nextToken();
				String port = st.nextToken();
				try {
					int n = Integer.parseInt(modul);
					if (n > 16) continue;
					n = Integer.parseInt(port);
					if (n > 32) continue;
				} catch (NumberFormatException e) {
					outle("  process3Com(): boksid: " + boksid + " modul: " + modul + " port: " + port + " NumberFormatException on modul|port: " + modul+"|"+port);
					continue;
				}
				String ifindex = modul+port;

				String status = "down";
				try {
					int n = Integer.parseInt(s[1]);
					if (n == 1 || n == 3) status = "up";
				} catch (NumberFormatException e) {
					outle("  process3Com(): boksid: " + boksid + " ifindex: " + ifindex + " NumberFormatException on status: " + s[1]);
					continue;
				}

				outl("  Added portData("+boksid+"): ifindex: " + ifindex + " Modul: " + modul + " Port: " + port + " Status: " + status + " Speed: " + speed + " Duplex: " + duplex + " Media: " + media);

				// PortData(String ifindex, String modul, String port, String status, String speed, String duplex, String media, boolean trunk, String portnavn)
				PortData pd = new PortData(ifindex, modul, port, status, speed, duplex, media, false, "");
				l.add(pd);
			}
		} else if (typegruppe.equals("3ss9300") || typegruppe.equals("3ss")) {
			// IfIndex: 1.3.6.1.2.1.2.2.1.2.ifindex = tekststring
			String ifIndexOid = "1.3.6.1.2.1.2.2.1.2";
			sSnmp.setParams(ip, cs_ro, ifIndexOid);
			ArrayList modulPortList = sSnmp.getAll(true);
			HashMap modulPortMap = new HashMap();
			for (int i=0; i < modulPortList.size(); i++) {
				String[] s = (String[])modulPortList.get(i);
				String ifindex = s[0];

				// Hent ut modul og port
				String modul;
				String port;
				if (typegruppe.equals("3ss9300")) {
					modul = "1";
				} else {
					modul = getNumAfterWord(s[1], "unit");
					if (modul == null) continue;
				}

				port = getNumAfterWord(s[1], "port");
				if (port == null) continue;

				modulPortMap.put(ifindex, new String[] { modul, port } );
			}

			HashMap mauTypeMap = new HashMap();
			if (typeid.equals("sw3300") || typeid.equals("sw1100")) {
				/*
				kan finnes fra ifMauType:
				.1.3.6.1.2.1.26.2.1.1.3.ifindex.1 = oid

				SW9300: N/A
				SW3300: 26.4.16 / enterprises.43.18.8.2.3
				SW1100: 26.4.10

				26.4.10: 10BaseTHD     10 HD
				26.4.11: 10BaseTFD     10 FD
				26.4.15: 100BaseTXHD  100 HD
				26.4.16: 100BaseTXFD  100 FD
				26.4.17: 100BaseFXHD  100 HD
				26.4.18: 100BaseFXFD  100 FD

			    1.3.6.1.4.1.43.18.8.2.2: 1000 BASE-SX / 1000Mbps FD
			    1.3.6.1.4.1.43.18.8.2.3: 1000 BASE-SX / 1000Mbps FD
			    1.3.6.1.4.1.43.18.8.2.7: 1000 BASE-T / 1000Mbps FD
			    1.3.6.1.4.1.43.18.8.2.9: 1000 BASE-T / 1000Mbps FD
				*/
				String _10BaseT = "10Base-T";
				if (typeid.equals("sw3300")) _10BaseT = "100Base-TX"; // 3300 har bare 100Mbit-porter

				HashMap oidMap = new HashMap();
				String pre = "1.3.6.1.2.1.26.4.";
				oidMap.put(pre+"10", new String[] { "10", "half", _10BaseT } );
				oidMap.put(pre+"11", new String[] { "10", "full", _10BaseT } );
				oidMap.put(pre+"15", new String[] { "100", "half", "100Base-TX" } );
				oidMap.put(pre+"16", new String[] { "100", "full", "100Base-TX" } );
				oidMap.put(pre+"17", new String[] { "100", "half", "100Base-FX" } );
				oidMap.put(pre+"18", new String[] { "100", "full", "100Base-FX" } );
				pre = "1.3.6.1.4.1.43.18.8.2.";
				oidMap.put(pre+"2", new String[] { "1000", "full", "1000Base-SX" } );
				oidMap.put(pre+"3", new String[] { "1000", "full", "1000Base-SX" } );
				oidMap.put(pre+"7", new String[] { "1000", "full", "1000Base-T" } );
				oidMap.put(pre+"9", new String[] { "1000", "full", "1000Base-T" } );

				String mauOid = "1.3.6.1.2.1.26.2.1.1.3";
				sSnmp.setParams(ip, cs_ro, mauOid);
				ArrayList mauTypeList = sSnmp.getAll(false);

				for (int i=0; i < mauTypeList.size(); i++) {
					String[] s = (String[])mauTypeList.get(i);
					StringTokenizer st = new StringTokenizer(s[0], ".");
					String ifindex = st.nextToken();
					String oid = s[1];
					if (oidMap.containsKey(oid)) {
						mauTypeMap.put(ifindex, oidMap.get(oid));
					} else {
						outle("  process3Com: boksid: " + boksid + " ifindex: " + ifindex + " Unknown mauOid: " + oid);
					}
				}
			} else if (typegruppe.equals("3ss9300")) {
				// .1.3.6.1.2.1.2.2.1.5
				// SW9300: Gauge32: 1000000000
				String speedOid = "1.3.6.1.2.1.2.2.1.5";
				sSnmp.setParams(ip, cs_ro, speedOid);
				ArrayList speedList = sSnmp.getAll();

				for (int i=0; i < speedList.size(); i++) {
					String[] s = (String[])speedList.get(i);
					String ifindex = s[0];
					long speedNum;
					try {
						speedNum = Long.parseLong(s[1]);
					} catch (NumberFormatException e) {
						outle("  process3Com: boksid: " + boksid + " ifindex: " + ifindex + " NumberFormatException on speed: " + s[1]);
						continue;
					}
					String speed = String.valueOf( (speedNum/1000000) );
					String duplex = "full";
					String media = "1000Base-SX";
					mauTypeMap.put(ifindex, new String[] { speed, duplex, media } );
				}
			}

			// S� sjekker vi status for porten, up|down
			HashMap statusMap = new HashMap();
			{
				String statusOid = "1.3.6.1.2.1.2.2.1.8";
				sSnmp.setParams(ip, cs_ro, statusOid);
				ArrayList statusList = sSnmp.getAll();

				for (int i=0; i < statusList.size(); i++) {
					String[] s = (String[])statusList.get(i);
					String ifindex = s[0];
					String status;
					try {
						int n = Integer.parseInt(s[1]);
						if (n == 1) {
							status = "up";
						} else if (n == 2) {
							status = "down";
						} else if (n == 0) {
							// FIXME
							status = "down";
						} else {
							outle("  process3Com: boksid: " + boksid + " ifindex: " + ifindex + " Unknown status code: " + n);
							continue;
						}
					} catch (NumberFormatException e) {
						outle("  process3Com: boksid: " + boksid + " ifindex: " + ifindex + " NumberFormatException for status code: " + s[1]);
						continue;
					}
					statusMap.put(ifindex, status);
				}
			}



			Iterator iter = modulPortMap.entrySet().iterator();
			while (iter.hasNext()) {
				Map.Entry me = (Map.Entry)iter.next();
				String ifindex = (String)me.getKey();
				String[] modulPort = (String[])me.getValue();
				String modul = modulPort[0];
				String port = modulPort[1];

				String[] mau = (String[])mauTypeMap.get(ifindex);
				if (mau == null) {
					outle("  process3Com: boksid: " + boksid + " ifindex: " + ifindex + " Could not find mauType for ifindex");
					continue;
				}

				String status = (String)statusMap.get(ifindex);
				if (status == null) {
					outle("  process3Com: boksid: " + boksid + " ifindex: " + ifindex + " Could not find status for ifindex");
					continue;
				}

				String speed = mau[0];
				String duplex = mau[1];
				String media = mau[2];

				outl("  Added portData("+boksid+"): ifindex: " + ifindex + " Modul: " + modul + " Port: " + port + " Status: " + status + " Speed: " + speed + " Duplex: " + duplex + " Media: " + media);

				// PortData(String ifindex, String modul, String port, String status, String speed, String duplex, String media, boolean trunk, String portnavn)
				PortData pd = new PortData(ifindex, modul, port, status, speed, duplex, media, false, "");
				l.add(pd);
			}








		} else {
			outle("  process3Com: boksid: " + boksid + " Unsupported typegruppe: " + typegruppe + " typeid: " + typeid);
			return l;
		}

		return l;
	}

	private static String getNumAfterWord(String s, String word) {
		s = s.toLowerCase();
		int i=0;
		while ( (i=s.indexOf(word, i)) >= 0) {
			int begin = s.indexOf(' ', i);
			if (begin < 0) return null;
			String t = s.substring(begin, s.length()).trim();

			int end = t.indexOf(' ');
			if (end >= 0) t = t.substring(0, end);

			try {
				int n = Integer.parseInt(t);
				return String.valueOf(n);
			} catch (NumberFormatException e) {
			}
		}

		return null;
	}


	private static void outa(String s) { System.out.print(s); }
	private static void outla(String s) { System.out.println(s); }

	private static void oute(Object s) { if (ERROR_OUT) System.out.print(s); }
	private static void outle(Object s) { if (ERROR_OUT) System.out.println(s); }

	private static void out(String s) { if (VERBOSE_OUT) System.out.print(s); }
	private static void outl(String s) { if (VERBOSE_OUT) System.out.println(s); }

	private static void outd(String s) { if (DEBUG_OUT) System.out.print(s); }
	private static void outld(String s) { if (DEBUG_OUT) System.out.println(s); }

	private static void err(Object o) { System.err.print(o); }
	private static void errl(Object o) { System.err.println(o); }
	private static void errflush() { System.err.flush(); }

}

class BoksData
{
	public String ip;
	public String cs_ro;
	public String boksId;
	public String boksTypegruppe;
	public String boksType;
	public String sysName;
	public String kat;
	public int vekt;
}


class PortData implements Comparable
{
	//String swportid;
	String ifindex;
	String modul;
	String port;

	String status;
	String speed;
	String duplex;
	String media;
	boolean trunk;
	String portnavn;

	int vlan = 1;

	public PortData(String ifindex, String modul, String port)
	{
		this.ifindex = ifindex.trim();
		this.modul = modul.trim();
		this.port = port.trim();

		this.status = "";
		this.speed = "";
		this.duplex = "";
		this.media = "";
		this.trunk = false;
		this.portnavn = "";
	}

	public PortData(String ifindex, String modul, String port, String status, String speed, String duplex, String media, boolean trunk, String portnavn)
	{
		this.ifindex = ifindex.trim();
		this.modul = modul.trim();
		this.port = port.trim();

		this.status = status.trim();
		this.speed = speed.trim();
		this.duplex = duplex.trim();
		this.media = media.trim();
		this.trunk = trunk;
		this.portnavn = portnavn.trim();
	}
	//public String getSwportid() { return swportid; }
	public String getIfindex() { return ifindex; }
	public String getIfindexS() { return ((ifindex.length()==1)?" ":"")+getIfindex(); }

	public String getModul() { return modul; }
	public String getModulS() { return ((modul.length()==1)?" ":"")+getModul(); }

	public String getPort() { return port; }
	public String getPortS() { return ((port.length()==1)?" ":"")+getPort(); }

	public String getStatus() { return status; }
	public String getStatusS() { return ((status.length()==2)?"  ":"")+status; }

	public String getSpeed() { return speed; }
	public String getDuplex() { return duplex; }
	public String getMedia() { return media; }
	public boolean getTrunk() { return trunk; }
	public String getTrunkS() { return trunk?"t":"f"; }
	public String getPortnavn() { return portnavn; }

	public void setStatus(String s) { status = s.trim(); }
	public void setSpeed(String s) { speed = s.trim(); }
	public void setDuplex(String s) { duplex = s.trim(); }
	public void setMedia(String s) { media = s.trim(); }
	public void setTrunk(boolean b) { trunk = b; }
	public void setPortnavn(String s) { portnavn = s.trim(); }

	public int getVlan() { return vlan; }
	public void setVlan(int i) { vlan = i; }


	public int compareTo(Object o) {
		PortData pd = (PortData)o;
		if (modul.equals(pd.getModul())) {
			return new Integer(port).compareTo(new Integer(pd.getPort()));
		}
		return new Integer(modul).compareTo(new Integer(pd.getModul()));
	}
	public String toString() { return getIfindexS()+" "+getModulS()+"/"+getPortS()+": Status: " + getStatusS() + " Speed: " + speed + " Duplex: " + duplex + " Media: " + media; }
}

class BoksReport implements Comparable
{
	int usedTime;
	BoksData bd;

	public BoksReport(int usedTime, BoksData bd)
	{
		this.usedTime = usedTime;
		this.bd = bd;
	}

	public int getUsedTime() { return usedTime; }
	public BoksData getBoksData() { return bd; }

	public int compareTo(Object o)
	{
		return new Integer(((BoksReport)o).getUsedTime()).compareTo(new Integer(usedTime));
	}
}
















