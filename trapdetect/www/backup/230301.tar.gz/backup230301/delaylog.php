<?php require('include.inc'); ?>

<?php tittel("ForsinketGSMlogg") ?>

Log'en som angir til hvem delayed GSM er sendt.

<?php topptabell(diverse) ?>

<h3>Ikke funksjonell enn�</h3>

	<?php

	$filename = "/home/trapdet/log/delayLog";

	$innhold = file($filename);

	$teller = 0;
	while($innhold[$teller]) {
	print ("$innhold[$teller]<br>");
	$teller++;
	}
	?>

<?php bunntabell() ?>
