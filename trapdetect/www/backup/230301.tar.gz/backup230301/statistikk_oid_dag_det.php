<?php require('include.inc'); ?>
<?php require('statistikk.inc'); ?>

<?php tittel("TrapDetect") ?>

Denne siden viser oversikt over hvilke traps denne enheten har sendt ut. Oversikten er begrenset til � vise
antall traps av hver type, mer detaljert informasjon m� finnes p� status, eller i hendelsesregistret.

<?php topptabell(statistikk) ?>

<?php

echo "<center><p><h3>OID'er mottatt fra $name den $date</h3></p></center>\n";

if ($date == date("dmy")) {
	$filename = "/home/trapdet/statistikk/oiddag.dat";
	list ($data,$max) = lagDataDet("oid", $filename, $name);
	list ($imagemap, $bilde) = tegnBilde($data, $max);

	echo "<center><img src=\"gif/$bilde.gif\" usemap=\"#map\" border=0></center>";

	$antall = sizeof($imagemap);
	echo "<map name=\"map\">";
	for ($i = 0; $i < $antall; $i++) {
		$navn = key ($imagemap);
		list($x,$y,$xx,$yy) = $imagemap[$navn];
		echo "<area shape=rect href=\"statistikk_meldinger.php?name=$name&antdager=0&oid=$navn\" coords=\"$x,$y,$xx,$yy\">\n";
		next($imagemap);
	}
	echo "</map>";

} else {

	$filename = "/home/trapdet/statistikk/log/oiddag.dat$date";
	if (is_file ($filename)) {
		list ($data,$max) = lagDataDet("oid", $filename, $name);
		list ($imagemap, $bilde) = tegnBilde($data, $max);
	
		echo "<center><img src=\"gif/$bilde.gif\" usemap=\"#map\" border=0></center>";

		$antall = sizeof($imagemap);
		echo "<map name=\"map\">";
		for ($i = 0; $i < $antall; $i++) {
			$navn = key ($imagemap);
			list($x,$y,$xx,$yy) = $imagemap[$navn];
			echo "<area shape=rect href=\"statistikk_meldinger.php?name=$name&antdager=0&oid=$navn&fname=history$date\" coords=\"$x,$y,$xx,$yy\">\n";
			next($imagemap);
		}
		echo "</map>";

	} else {
		echo "Beklager vi har ikke data for denne dagen.<br>\n";
	}
}


?>


<?php bunntabell() ?>
