<?php require('include.inc'); ?>

<?php tittel("Admin") ?>

Velkommen til adminsiden. Velg de innlegg som skal redigeres med � trykke p� knappen fremfor innlegget. Skriv inn navn p� person som redigerer. Velg friskmeld eller slett, alt etter hva du vil gj�re. Trykk Submit for � utf�re redigeringen.<br><br>
Ved sletting vil innlegg bli slettet fra status-oversikten, og fra hendelsesregistret.<br>
Ved friskmelding vil innlegg bli slettet fra status-oversikten, og f�rt opp som friskmeldt i hendelsesregistret med navn p� friskmelder.

<?php topptabell(diverse) ?>

<form action="slett.php3" method="GET">
<input type=radio name=knapp value=slett>Slett
<input type=radio name=knapp value=friskmeld>Friskmeld<br>
<input type=tekst name=navn value=Navn>
<input type=submit value=Submit><br>

<?php

	$filename = "/home/trapdet/sick";
	$innhold = file($filename);

	function skrivalt($innhold) {
		$teller = 0;
		$teller2 = 1;
		$innlegg = 0;
	
	$streng .= "<input type=checkbox name=b$innlegg value=$teller2>";
		while($innhold[$teller]) {
			if (preg_match("/^-/", $innhold[$teller])) {
				$innlegg++;
				$streng .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$innhold[$teller]<br>\n";
				$box = 1;
			} elseif ($box) {
				$streng .= "<input type=checkbox name=b$innlegg value=$teller2>";
				$streng .= "$innhold[$teller]<br>\n";
				$box = 0;
			} else {
				$streng .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$innhold[$teller]<br>\n";
			}
			$teller++;
			$teller2++;
		}
		$streng .= "<input type=hidden name=antall value=$innlegg>\n";
		return array ($innlegg,$streng);
	}
	
	list ($antall, $streng) = skrivalt($innhold);
	print "<b>Antall innlegg: $antall</b><br><br>\n";
	print "$streng<br>\n";
?>

</form>

<?php bunntabell() ?>













