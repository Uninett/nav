<?php require('include.inc'); ?>

<?php tittel("Dagens hendelsesregister") ?>

<p>Velkommen til varslingsregistrering. Dette er en 3-stegsprosess der
du m� gjennom f�lgende punkter:
<ul>
	<li>Valg av Trap for varsling
	<li>Valg av eventuelle enheter.
	<li>Valg av varslingstype
</ul></p>

<?php topptabell(hendelsesregister) ?>

<p>Her er alle traps du har tilgang til med din
organisasjonstilh�righet. Velg trap du vil abonnere p� og trykk g�
videre.</p>

<?php

	# Connecter til db
	$dbh = mysql_connect("localhost", "nett", "stotte") or die ("Kunne ikke �pne connection til databasen.");

	# Henter alle orger bruker er medlem i
	mysql_select_db("manage",$dbh);

	$sporring = "select trapdetect.org.navn from trapdetect.useriorg,trapdetect.org,manage.user where manage.user.id=trapdetect.useriorg.userid and trapdetect.useriorg.orgid=trapdetect.org.id and manage.user.user='".$bruker."'";
	$result = mysql_query($sporring, $dbh);

	$eier = array();
	while ($row = mysql_fetch_row($result)) {
		array_push($eier,$row[0]);
	}

	# Henter suboid'er fra databasen og hiver de inn i et array til senere bruk.
	mysql_select_db("trapdetect", $dbh);

	# Sp�r etter organisasjonsforhold, som kan v�re flere for en bruker
	$antall_org = sizeof($eier);
	$sporring = "select syknavn,beskrivelse from trap,trapeier,org where (";
	foreach ($eier as $navn) {
		$teller++;
		if ($teller < $antall_org) {
			$sporring .= "org.navn='".$navn."' or ";
		} else {
			$sporring .= "org.navn='".$navn."')";
		}
	}
	$sporring .= " and trapeier.orgid=org.id and trap.id=trapid group by syknavn order by syknavn";
	$result = mysql_query($sporring,$dbh);

	echo "<form action=meldingssystem2.php method=\"POST\">";
	echo "Velg trap: <select name=trap>\n";

	$besk = array();
	while ($row = mysql_fetch_array($result)) {
		# Skriver ut listen over alle oid'er som man kan velge � s�ke etter.
		echo "<option value=".$row["syknavn"].">".$row["syknavn"]."\n";

		# Tar vare p� bekrivelsene
		$besk[$row["syknavn"]] = $row["beskrivelse"];
	}

	echo "</select>\n";

	# Skriver ut alle orgforholdene og navnet p� bruker
	echo "<input type=hidden name=bruker value=$bruker>";
	foreach ($eier as $navn) {
		echo "<input type=hidden name=eier[] value=$navn>";
	}
	echo "<input type=submit value=\"G� videre\">\n";
	echo "</form>\n";

	# Skriver ut beskrivelse av alle traps
	$keys = array_keys($besk);
	foreach ($keys as $key) {
		echo "<B>".$key."</B>: ".$besk[$key]."<br>\n";
	}

?>

<?php bunntabell() ?>
