<!-- F�r inn disse variable:
	eier: kan v�re flere variable
	trap: sier seg selv
	bruker: brukernavn p� han som er p�
-->
<html><body>

<p>Her er oversikt over alle kategorier og underkategorier som tilh�rer <?php echo $trap ?>-trap'en. Velg kategori (og evt. underkategori) du vil abonnere p�.</p>

<?php


$border=0;

$postvars = $HTTP_POST_VARS;
$keys = array_keys($postvars);
$eier = $postvars["eier"];

##################################################
# En liten ting som viser hjelp om n�dvendig
##################################################
echo "<form action=meldingssystem2.php method=\"POST\">\n";
if ($vis_hjelp == "on") {

	$string = "<p>Velg de kategoriene du vil abonnere p� ved �
	klikke i boksene.</p>

	<p>Merking er lagt opp p� en tiln�rmet hierarkisk m�te. Hvis
	du bare krysser av for en kategori velger du alle enhetene som
	er i den kategorien. Hvis du krysser av for en kategori og
	deretter en underkategori, betyr det at du IKKE vil ha med
	underkategorien. Hvis du i tillegg krysser av en enhet som er
	under underkategorien, legger du den TIL.</p>

	<p>Hvis du er usikker er det bare � pr�ve og trykke <b>G�
	videre</b> for � se hvilke enheter som er valgt. Hvis det er
	feil, trykker du p� <b>Tilbake</b> knappen i browseren og
	velger p� nytt.</p>

	<p>NB! N�r det gjelder listene er det er forskjellige m�ter �
	velge p� ettersom hvilken browser du har. I Netscape er det
	bare � klikke. I Opera og Internet Explorer m� du trykke inn
	CTRL+Venstre musknapp for � velge flere enheter eller velge
	vekk den du har valgt.</p>";

	echo $string;
	foreach ($eier as $name) {
		echo "<input type=hidden name=eier[] value=$name>\n";
	}
	echo "<input type=hidden name=bruker value=".$bruker.">\n";
	echo "<input type=hidden name=trap value=".$trap.">\n";
	echo "<input type=submit value=\"Fjern hjelp\">";
	echo "</form>\n";
} else {
	foreach ($eier as $name) {
		echo "<input type=hidden name=eier[] value=$name>\n";
	}
	echo "<input type=hidden name=vis_hjelp value=\"on\">\n";
	echo "<input type=hidden name=bruker value=".$bruker.">\n";
	echo "<input type=hidden name=trap value=".$trap.">\n";
	echo "<input type=submit value=\"Vis hjelp\">";
	echo "</form>\n";
}


echo "<form action=meldingssystem.php align=right method=\"POST\">";
echo "<input type=hidden name=bruker value=$bruker>";
echo "<input type=submit value=\"Tilbake til registrering\" align=right>\n";
echo "</form><br>\n";

echo "<hr width=90%>\n";

##############################
# Kobler til database
##############################
$dbh = mysql_connect("localhost", "nett", "stotte") or die ("Kunne ikke �pne connection til databasen.");
mysql_select_db("trapdetect", $dbh);

##################################################
# Henter alle varslingstyper fra databasen, 
# legger de i et array for senere bruk.
##################################################
$result = mysql_query("select * from varseltype");
while ($svar = mysql_fetch_row($result)) {
	$varseltype[$svar[1]] = $svar[0];
}
$type = array_keys($varseltype);

##################################################
# Henter tilgjenglige kategorier for trap'en
##################################################
$sporring = "select trapkat.kat from trapkat,trap where trap.syknavn='".$trap."' and trap.id=trapkat.trapid";
$res = mysql_query($sporring,$dbh);

if (mysql_num_rows($res) == 0) {
	echo "Denne type trap er uavhengig av enheter.<br>\n";
	echo "Velg varslingstype for ".$trap.":\n";
	echo "<form action=meldingssystem4.php method=\"POST\">";
	lagDropDown($type,"spesial");
} else {

$antall_enheter = 0;
$kategorier = array();

######################################################################
# Sjekker eierforholdet mellom enhetene i de tilgjengelige kat og brukerens org.
# $row[kat] er alle kategoriene som er funnet med kat som key
# $rows[] inneholder alle underkategoriene
# $antall_i_kat er antallet enheter i hver kat for medlemmen i denne org'en
######################################################################
mysql_select_db("manage", $dbh);
$antall_i_kat = array();
while ($row = mysql_fetch_array($res)) {
	# M� hente inn alle eierforhold
	$sporring = "select count(kat),underkat from nettel where kat='".$row["kat"]."' and (";
	for ($i=0;$i<sizeof($eier);$i++) {
		if ($i<(sizeof($eier)-1)) {
			$sporring .= "eier='".$eier[$i]."' or ";
		} else {
			$sporring .= "eier='".$eier[$i]."'";
		}
	}
	$sporring .= ") group by underkat";

	$result = mysql_query($sporring,$dbh);
	$antall = mysql_num_rows($result);

	if ($antall > 0) { # Hvis det finnes underkategorier
		$temparray = array();
		while ($rows = mysql_fetch_row($result)) {
			$antall_enheter += $rows[0]; # Teller opp totalt antall enheter
			$antall_i_kat[$row["kat"]] += $rows[0];
			if ($rows[1]) { # Hvis det er en verdi der, fortsetter vi
				array_push ($temparray, $rows[1]); # Legger alle underkat i en array
			}
		}
		$kategorier[$row["kat"]] = $temparray; # Ferdig med alle underkategoriene, hiver dem i en hash
	}
}

$keys = array_keys($kategorier);
if (sizeof ($keys) > 1) {
	echo "Det er totalt ".$antall_enheter." enheter i disse kategoriene.<br>\n";
} else {
	echo "Det er totalt ".$antall_enheter." enheter i denne kategorien.<br>\n";
}
##################################################
# Skriver ut alle kategorier og underkategorier 
# og lister over enheter med i dem.
##################################################
echo "<form action=meldingssystem3.php method=\"POST\">";
echo "\n<table width=90%  cellpadding=3 border=$border>";
foreach ($keys as $key) { # G�r gjennom alle kategorier
	echo "\n\t<tr><td valign=top>\n";

	$underkat = $kategorier[$key];
	$tempkey = strtoupper($key); # Kun for syns skyld -> uppercase
	echo "\t<input type=checkbox name=kat_".$key.">".$tempkey."<br>(".$antall_i_kat[$key]." enheter)";

	echo "\t</td>\n";

	if (sizeof($underkat) > 0) { # Hvis det ikke er underkat'er s� skipper vi dette.
		$harunderkat = 1;
		echo "\t<td valign=top>\n\t\t<table cellpadding=8 border=$border><tr><td valgin=top>\n";
		echo "\t\tVelg underkategorier for ".$key."\n</td>";
		echo "\t\t<td>Enheter med i $key\n";
		echo "\t\t</td></tr>\n";
		foreach($underkat as $element) {
			$sporring = "select sysname from nettel where kat='".$key."' and underkat='".$element."' and (";
			for ($i=0;$i<sizeof($eier);$i++) {
				if ($i<(sizeof($eier)-1)) {
					$sporring .= "eier='".$eier[$i]."' or ";
				} else {
					$sporring .= "eier='".$eier[$i]."' ";
				}
			}
			$sporring .= ") order by sysname";

			$res = mysql_query($sporring,$dbh);
			$antall = mysql_num_rows($res);

			# Skriver ut underkategorien og lager en checkbox.
			echo "\n\t\t<tr><td>";
			echo "\n\t\t<input type=checkbox name=".$key."_".$element.">".$element."(".$antall.")";
			echo "</td><td>\n";

			# Lager en liste over alle enheter med denne kategori og underkategori
			echo "\t\t<select name=list_".$key."_".$element."[] multiple size=3>";
			while ($rad = mysql_fetch_row($res)) {
				echo "\n\t\t\t<option>$rad[0]</option>";
			}
			echo "</select>\n";
			echo "\t\t</td></tr>";
		}
		echo "</table>\n";
		echo "</td>";
		echo "</tr>";
	}

	# Listen over alle enheter med denne kategori som ikke er med i noen underkategori.
	$sporring = "select sysname from nettel where kat='".$key."' and (underkat is null or underkat='') and (";
		for ($i=0;$i<sizeof($eier);$i++) {
			if ($i<(sizeof($eier)-1)) {
				$sporring .= "eier='".$eier[$i]."' or ";
			} else {
				$sporring .= "eier='".$eier[$i]."' ";
			}
		}
	$sporring .= ") order by sysname";

	$res = mysql_query($sporring,$dbh);
	$antall = mysql_num_rows($res);
	if ($antall > 0) {
		if ($harunderkat) {
			echo "<td>&nbsp</td>";
		}
		echo "\n\t\t<td valign=bottom>";
		echo "Enheter i $key uten underkategori";
		echo "</td></tr><tr><td>&nbsp</td><td>";
		echo "<select name=list_".$key."[] multiple size=10>";
		while ($rad = mysql_fetch_row($res)) {
			echo "<option>$rad[0]</option>\n";
		}
		echo "</select>";
		echo "\n\t</td></tr>\n";
	}
}
echo "</table>\n";

}

foreach ($eier as $name) {
	echo "<input type=hidden name=eier value=".$name.">\n";
}
echo "<input type=hidden name=bruker value=".$bruker.">\n";
echo "<input type=hidden name=trap value=".$trap.">\n";
echo "<input type=submit value=\"G� videre\">";
echo "</form>\n";

# Stygg m�te � resette p�... :)
echo "<form action=meldingssystem2.php method=\"POST\">";
foreach ($eier as $name) {
	echo "<input type=hidden name=eier[] value=$name>\n";
}
echo "<input type=hidden name=bruker value=".$bruker.">\n";
echo "<input type=hidden name=trap value=$trap>";
echo "<input type=submit value=Reset>";
echo "</form>";

##################################################
# En funksjon som skriver ut en drop-down
# liste som inneholder alle varseltypene som 
# er i databasen.
##################################################
function lagDropDown($array,$name) {
	global $varseltype;
	echo "<select name=$name>\n";
	foreach ($array as $element) {
		if ($element == "mail") {
			echo "<option value=".$varseltype[$element]." selected>".$element."</option>\n";
		} else {
			echo "<option value=".$varseltype[$element].">".$element."</option>\n";
		}
	}
	echo "</select>\n";
}


?>

</body></html>
