<html><body>

<?php

$keys = array_keys($HTTP_POST_VARS);

# Kobler til database.
echo "Oppretter kontakt med databasen...";
$dbh = mysql_connect("localhost", "nett", "stotte") or die ("Kunne ikke �pne connection til databasen.");
echo "ok<br>\n";

##################################################
# Henter n�dvendige data; brukerid og trapid
##################################################
mysql_select_db("trapdetect", $dbh);
$resultat = mysql_query("select id from trap where syknavn='".$trap."'");
$trapid = mysql_fetch_row($resultat); # id ligger n� i trapid[0]

mysql_select_db("manage", $dbh);
$resultat = mysql_query("select id from user where user='".$bruker."'");
$userid = mysql_fetch_row($resultat);

##################################################
# Parser variable og lager sp�rringer.
##################################################

# Leter f�rst etter unntak som vi m� ha for � lage sp�rringer.
$ukatunntak = array();
$enhetunntak = array();

if ($HTTP_POST_VARS["unntak"]) {
	foreach ($HTTP_POST_VARS["unntak"] as $element) {
		if (preg_match("/(.+),(.+)/",$element,$matches)) { # Dette er et underkategoriunntak
			$var = array();
			if ($ukatunntak[$matches[1]]) {
				$var = $ukatunntak[$matches[1]];
				array_push($var,$matches[2]);
				$ukatunntak[$matches[1]] = $var;
			} else {
				$var = array();
				array_push($var,$matches[2]);
				$ukatunntak[$matches[1]] = $var;
			}
		} else { # Dette er en enhet
			array_push($enhetunntak,$element);
		}
	}
}

################################################################################
# Under sp�rringene behandler jeg unntak slik:
# Hvis det bare er en kategori uten unntak p� underkategoriene, lager jeg 
# sp�rringen direkte, med bare kat satt i varsel.
# Hvis det er en kategori MED unntak p� underkategoriene, m� jeg hente alle
# unntak. Lager s� sp�rringen og setter B�DE kat og ukat i varsel.
# Hvis det er en underkategori uten kategori, legger jeg den direkte inn
# i varsel UTEN kat.
#
# Dette er viktig � forst� for uthenting av varsel.
################################################################################
$sporringer = array();
mysql_select_db("trapdetect", $dbh);
foreach ($keys as $element) {
	if (preg_match("/^kat:(.+)/",$element,$matches)) { # Vi har funnet en hovedkategori
		if (in_array($matches[1],array_keys($ukatunntak))) { # Finner ukatunntak for denne kategorien
			foreach ($ukatunntak[$matches[1]] as $unntak) {
				$sporring = "insert into varsel (userid,trapid,kat,ukat,vtypeid) values (".$userid[0].",".$trapid[0].",'".$matches[1]."','".$unntak."',".$HTTP_POST_VARS[$matches[0]].")";
				array_push($sporringer,$sporring);
				
			}
		} else {
			$sporring = "insert into varsel (userid,trapid,kat,vtypeid) values (".$userid[0].",".$trapid[0].",'".$matches[1]."',".$HTTP_POST_VARS[$matches[0]].")";
			array_push($sporringer,$sporring);
		}
	} elseif (preg_match("/^ukat:(.+),(.+)/",$element,$matches)) { # Vi har funnet en underkategori
		$sporring = "insert into varsel (userid,trapid,ukat,vtypeid) values (".$userid[0].",".$trapid[0].",'".$matches[2]."',".$HTTP_POST_VARS[$matches[0]].")";
		array_push($sporringer,$sporring);
	} elseif (preg_match("/enhet:(.+)/",$element,$matches)) { # Vi har funnet en enhet som skal legges til.
		mysql_select_db("manage", $dbh);
		$res = mysql_query("select id from nettel where sysname='".$matches[1]."'");
		if (mysql_num_rows($res) == 0) { # Noe gikk galt, kanskje med sysname
#			echo "Pr�ver annen sp�rring -> ";
			$matches[1] = preg_replace("/_/",".",$matches[1]); # Skifter underscore med punktum
			$res = mysql_query("select id from nettel where sysname='".$matches[1]."'"); # Ny sp�rring kj�res
		}
#		echo "select id from nettel where sysname='".$matches[1]."'<br>";
		$enhet = mysql_fetch_row($res);
		$sporring = "insert into unntak (userid,trapid,nettelid,vtypeid,status) values (".$userid[0].",".$trapid[0].",".$enhet[0].",".$HTTP_POST_VARS[$matches[0]].",'pluss')";
		array_push($sporringer,$sporring);
	} elseif (preg_match("/spesial/",$element)) { # Denne kommer av traps uavhengige av enheter
		$sporring = "insert into varsel (userid,trapid,vtypeid) values (".$userid[0].",".$trapid[0].",".$HTTP_POST_VARS["spesial"].")";
		array_push($sporringer,$sporring);
	}
}

##################################################
# Ferdig med alle elementene i inputstrengen,
# trenger n� � skrive alle unntak for enheter som
# er i $enhetunntak til unntak-tabellen.
##################################################
foreach ($enhetunntak as $innlegg) {
	mysql_select_db("manage", $dbh);
	$res = mysql_query("Select id from nettel where sysname='".$innlegg."'");
	$enhet = mysql_fetch_row($res);
	$sporring = "insert into unntak (userid,trapid,nettelid,status) values (".$userid[0].",".$trapid[0].",".$enhet[0].",'minus')";
	array_push($sporringer,$sporring);
}

######################################################################
# Legger alle sp�rringene inn i databasen.
#
# Sletter f�rst alle innlegg med samme bruker og trap som eksisterer
# fra f�r. S� legges alle innleggene inn.
######################################################################
mysql_select_db("trapdetect", $dbh);
mysql_query("delete from varsel where userid=".$userid[0]." and trapid=".$trapid[0]);
mysql_query("delete from unntak where userid=".$userid[0]." and trapid=".$trapid[0]);
foreach ($sporringer as $sporring) {
	echo "$sporring<br>\n";
	mysql_query($sporring);
}

echo "<form action=meldingssystem.php method=\"POST\">";
echo "<input type=hidden name=bruker value=$bruker>";
echo "<input type=submit value=\"Tilbake til registrering\">\n";
echo "</form>\n";


?>
</body></html>

