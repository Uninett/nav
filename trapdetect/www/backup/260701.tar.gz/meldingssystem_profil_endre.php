<?php 

require('meldingssystem.inc');
html_topp("Endringen er lagret");

$vars = $HTTP_POST_VARS;
if ($vars[sms] == 'on') {
  $vars[sms] = 'Y';
} else {
  $vars[sms] = 'N';
}

#skrivpost($vars);

list ($bruker,$admin) = verify_user($bruker,$REMOTE_USER);

# Oppretter kontakt med databasen.
$dbh = mysql_connect("localhost","nett","stotte");
mysql_select_db('trapdetect');

########################################
# Legger data inn i databasen
# Gj�res ved � oppdatere det som er der 
# fra f�r.
########################################
if ($admin) {
  $sporring = "update user set mail='$vars[mail]',tlf='$vars[tlf]',org='$vars[org]',status='$vars[status]'";
  $sporring .= ",sms='$vars[sms]', dsms_fra='$vars[dsmsfra]',dsms_til='$vars[dsmstil]' where user='$bruker'";
} else {
  $sporring = "update user set mail='$vars[mail]',tlf='$vars[tlf]',status='$vars[status]'";
  $sporring .= ",dsms_fra='$vars[dsmsfra]',dsms_til='$vars[dsmstil]' where user='$bruker'";
}
#print "$sporring<br>\n";
$done = mysql_query($sporring);

# Skriver status-melding
if ($done) {
  print "Databasen oppdatert. G� tilbake til hovedsiden<br>\n";
} else {
  print "En feil skjedde under innlegging i databasen. G� tilbake til hovedsiden<br>\n";
}

# Skriver tilbake-til-hovedsidenknapp
knapp_hovedside($bruker);

?>

</body></html>