<?php
require ('meldingssystem.inc');

list ($bruker,$admin) = verify_user($bruker,$REMOTE_USER);

html_topp("Varslingsregistrering - Steg 1");

if ($admin && $REMOTE_USER != $bruker) {
  print "Du er innlogget som <b>$bruker</b> med administratorrettighetene til <b>$REMOTE_USER</b><br>\n";
}
echo "<p>Velkommen til varslingsregistrering. Dette er en 3-stegsprosess der
du m� gjennom f�lgende punkter:";

echo "<ul><li>Steg 1: Valg av Trap for varsling";
echo "<li>Steg 2: Valg av eventuelle enheter.";
echo "<li>Steg 3: Valg av varslingstype";
echo "</ul></p>";

echo "<hr width=90%>";

echo "<p><h3>STEG 1</h3>Her er alle traps du har tilgang til med <b>$bruker</b> sin ";
echo "organisasjonstilh�righet. Velg trap du vil abonnere p� og trykk <b>g� videre</b>.</p>";


# Connecter til db
$dbh = mysql_connect("localhost", "nett", "stotte") or die ("Kunne ikke �pne connection til databasen.");

# Henter alle orger bruker er medlem i
mysql_select_db("manage",$dbh);

$sporring = "select trapdetect.org.navn from trapdetect.useriorg,trapdetect.org,manage.user where manage.user.id=trapdetect.useriorg.userid and trapdetect.useriorg.orgid=trapdetect.org.id and manage.user.user='".$bruker."'";

$result = mysql_query($sporring, $dbh);

$eier = array();
while ($row = mysql_fetch_row($result)) {
  array_push($eier,$row[0]);
}

# Henter suboider fra databasen og hiver de inn i et array til senere bruk.
mysql_select_db("trapdetect", $dbh);

# Sp�r etter organisasjonsforhold, som kan v�re flere for en bruker
$antall_org = sizeof($eier);
$sporring = "select syknavn,beskrivelse from trap,trapeier,org where (";

foreach ($eier as $navn) {
  $teller++;
  if ($teller < $antall_org) {
    $sporring .= "org.navn='".$navn."' or ";
  } else {
    $sporring .= "org.navn='".$navn."')";
  }
}

$sporring .= " and trapeier.orgid=org.id and trap.id=trapid group by syknavn order by syknavn";
$result = mysql_query($sporring,$dbh);

echo "<form action=meldingssystem2.php method=\"POST\">";
echo "Velg trap: <select name=trap>\n";

$besk = array();

while ($row = mysql_fetch_array($result)) {
# Skriver ut listen over alle oider som man kan velge � s�ke etter.
  echo "<option value=".$row["syknavn"].">".$row["syknavn"]."\n";
# Tar vare p� bekrivelsene
  $besk[$row["syknavn"]] = $row["beskrivelse"];
}

echo "</select>\n";

# Skriver ut alle orgforholdene og navnet p� bruker
echo "<input type=hidden name=bruker value=$bruker>";
foreach ($eier as $navn) {
  echo "<input type=hidden name=eier[] value=$navn>";
}
echo "<input type=submit value=\"G� videre\">\n";
echo "</form>\n";

# Skriver ut beskrivelse av alle traps
$keys = array_keys($besk);
foreach ($keys as $key) {
  echo "<B>".$key."</B>: ".$besk[$key]."<br>\n";
}

knapp_hovedside($bruker);

echo "</body></html>";

?>