<html><body>
<!-- F�r inn disse variable:
eier: kan v�re flere variable
trap: sier seg selv
bruker: brukernavn p� han som er p�
-->

<head>
<script Language="JavaScript">
<!--
function popup(url, name, width, height)
{
  settings=
  "toolbar=no,location=no,directories=no,"+
  "status=no,menubar=no,scrollbars=yes,"+
  "resizable=yes,width="+width+",height="+height;
  MyNewWindow=window.open(url,name,settings);
}
//-->
</script>

</head>

<p><h3>STEG 2</h3>Her er oversikt over alle kategorier og underkategorier som tilh�rer <?php echo $trap ?>-trapen. Velg kategori (og evt. underkategori) du vil abonnere p� og trykk <b>G� videre</b> nederst p� siden.</p>

<?php

$border=0;

$postvars = $HTTP_POST_VARS;
$keys = array_keys($postvars);
$eier = $postvars["eier"];
foreach ($keys as $key) {
# Skifter _ til . i navnet til enhetene.
  $tempkey = preg_replace("/_/",".",$key);
  $HTTP_POST_VARS[$tempkey] = $postvars[$key];
  
#	if (preg_match("/list/",$key)) {
#		foreach ($postvars[$key] as $temp) {
#			echo "$key -> $temp<br>\n";
#		}
#	} else {
#		echo "$key -> $postvars[$key]<br>\n";
#	}
}

##################################################
# En liten ting som viser hjelp om n�dvendig
##################################################

echo "<p><a href=\"#\" onClick=\"popup('meldingssystem2_hjelp.html', 'Win1', 500, 300); return false\">Hjelp</a></p>\n";

echo "<form action=meldingssystem.php method=\"POST\">";
echo "<input type=hidden name=bruker value=$bruker>";
echo "<input type=submit value=\"Tilbake til steg 1\">\n";
echo "</form><br>\n";

echo "<hr width=90%>\n";

##############################
# Kobler til database
##############################
$dbh = mysql_connect("localhost", "nett", "stotte") or die ("Kunne ikke �pne connection til databasen.");
mysql_select_db("trapdetect", $dbh);

##################################################
# Henter alle varslingstyper fra databasen, 
# legger de i et array for senere bruk.
##################################################
$result = mysql_query("select * from varseltype");
while ($svar = mysql_fetch_row($result)) {
$varseltype[$svar[1]] = $svar[0];
}
$type = array_keys($varseltype);

##################################################
# Henter tilgjenglige kategorier for trapen
##################################################
$sporring = "select trapkat.kat from trapkat,trap where trap.syknavn='".$trap."' and trap.id=trapkat.trapid";
$res = mysql_query($sporring,$dbh);

if (mysql_num_rows($res) == 0) {
  echo "Denne type trap er uavhengig av enheter.<br>\n";
  echo "Velg varslingstype for ".$trap.":\n";
  echo "<form action=meldingssystem4.php method=\"POST\">";
  lagDropDown($type,"spesial");
} else {

  $antall_enheter = 0;
  $kategorier = array();

######################################################################
# Sjekker eierforholdet mellom enhetene i de tilgjengelige kat og brukerens org.
# $row[kat] er alle kategoriene som er funnet med kat som key
# $rows[] inneholder alle underkategoriene
# $antall_i_kat er antallet enheter i hver kat for medlemmen i denne org'en
######################################################################
mysql_select_db("manage", $dbh);
$antall_i_kat = array();

while ($row = mysql_fetch_array($res)) {

# M� hente inn alle eierforhold
$sporring = "select count(kat),underkat from nettel where kat='".$row["kat"]."' and (";

for ($i=0;$i<sizeof($eier);$i++) {

if ($i<(sizeof($eier)-1)) {
$sporring .= "eier='".$eier[$i]."' or ";
} else {
$sporring .= "eier='".$eier[$i]."'";
}
}
$sporring .= ") group by underkat";

$result = mysql_query($sporring,$dbh);
$antall = mysql_num_rows($result);

if ($antall > 0) { # Hvis det finnes underkategorier
$temparray = array();
while ($rows = mysql_fetch_row($result)) {
$antall_enheter += $rows[0]; # Teller opp totalt antall enheter
$antall_i_kat[$row["kat"]] += $rows[0];
if ($rows[1]) { # Hvis det er en verdi der, fortsetter vi
array_push ($temparray, $rows[1]); # Legger alle underkat i en array
}
}
$kategorier[$row["kat"]] = $temparray; # Ferdig med alle underkategoriene, hiver dem i en hash
}
}

$keys = array_keys($kategorier);
echo "Det er totalt ".$antall_enheter." enheter tilgjengelig for <b>$trap</b> for bruker <b>$bruker</b><br>\n";

##################################################
# Skriver ut alle kategorier og underkategorier 
# og lister over enheter med i dem.
##################################################
echo "<form action=meldingssystem3.php method=\"POST\">";
echo "\n<table width=90%  cellpadding=3 border=$border>";

foreach ($keys as $key) { # G�r gjennom alle kategorier
echo "\n\t<tr><td valign=top>\n";

$underkat = $kategorier[$key];
$tempkey = strtoupper($key); # Kun for syns skyld -> uppercase

# KATEGORIER - sjekker om variabelnavn lik kategori finnes

if ($HTTP_POST_VARS[$key]) {
echo "\t<input type=checkbox name=kat_".$key." checked>".$tempkey."<br>(".$antall_i_kat[$key]." enheter)";
} else {
echo "\t<input type=checkbox name=kat_".$key.">".$tempkey."<br>(".$antall_i_kat[$key]." enheter)";
}

echo "\t</td>\n";

if (sizeof($underkat) > 0) { # Hvis det ikke er underkat'er s� skipper vi dette.
								 $harunderkat = 1;
  echo "\t<td valign=top>\n\t\t<table cellpadding=8 border=$border><tr><td valgin=top>\n";
  echo "\t\tVelg underkategorier for ".$key."\n</td>";
  echo "\t\t<td>Enheter med i $key\n";
  echo "\t\t</td></tr>\n";
  foreach($underkat as $element) {
    $sporring = "select sysname from nettel where kat='".$key."' and underkat='".$element."' and (";
    for ($i=0;$i<sizeof($eier);$i++) {
      if ($i<(sizeof($eier)-1)) {
	$sporring .= "eier='".$eier[$i]."' or ";
      } else {
	$sporring .= "eier='".$eier[$i]."' ";
      }
    }
    $sporring .= ") order by sysname";

    $res = mysql_query($sporring,$dbh);
    $antall = mysql_num_rows($res);

# Skriver ut underkategorien og lager en checkbox.
    echo "\n\t\t<tr><td>";

# UNDERKATEGORIER - sp�r om variabel med kat finnes og om variabel med ukat finnes
    if ($HTTP_POST_VARS[$element] == $key) {
      echo "\n\t\t<input type=checkbox checked name=".$key."_".$element.">".$element."(".$antall.")";
    } else {
      echo "\n\t\t<input type=checkbox name=".$key."_".$element.">".$element."(".$antall.")";
    }
    echo "</td><td>\n";

# Lager en liste over alle enheter med denne kategori og underkategori
    echo "\t\t<select name=list_".$key."_".$element."[] multiple size=3>";
    while ($rad = mysql_fetch_row($res)) {

# ENHETER MED UNDERKATEGORI - variabelnavn med enhet brukes
      if ($HTTP_POST_VARS[$rad[0]]) {
	echo "\n\t\t\t<option selected>$rad[0]</option>";
      } else {
	echo "\n\t\t\t<option>$rad[0]</option>";
      }
    }
    echo "</select>\n";
    echo "\t\t</td></tr>";
  }
  echo "</table>\n";
  echo "</td>";
  echo "</tr>";
}

# Listen over alle enheter med denne kategori som ikke er med i noen underkategori.
$sporring = "select sysname from nettel where kat='".$key."' and (underkat is null or underkat='') and (";
for ($i=0;$i<sizeof($eier);$i++) {
  if ($i<(sizeof($eier)-1)) {
    $sporring .= "eier='".$eier[$i]."' or ";
  } else {
    $sporring .= "eier='".$eier[$i]."' ";
  }
}
$sporring .= ") order by sysname";

$res = mysql_query($sporring,$dbh);
$antall = mysql_num_rows($res);
if ($antall > 0) {
  if ($harunderkat) {
    echo "<td>&nbsp</td>";
  }
  echo "\n\t\t<td valign=bottom>";
  echo "Enheter i $key uten underkategori";
  echo "</td></tr><tr><td>&nbsp</td><td>";
  echo "<select name=list_".$key."[] multiple size=10>";
  while ($rad = mysql_fetch_row($res)) {
# ENHETER UTEN UNDERKATEGORI - sjekker om variabel lik navn p� enhet finnes
    if ($HTTP_POST_VARS[$rad[0]]) {
      echo "<option selected>$rad[0]</option>\n";
    } else {
      echo "<option>$rad[0]</option>\n";
    }
  }
  echo "</select>";
  echo "\n\t</td></tr>\n";
}
}
echo "</table>\n";

}

foreach ($eier as $name) {
echo "<input type=hidden name=eier value=".$name.">\n";
}
echo "<input type=hidden name=bruker value=".$bruker.">\n";
echo "<input type=hidden name=trap value=".$trap.">\n";
echo "<input type=submit value=\"G� videre\">";
echo "</form>\n";

# Stygg m�te � resette p�... :)
echo "<form action=meldingssystem2.php method=\"POST\">";
foreach ($eier as $name) {
echo "<input type=hidden name=eier[] value=$name>\n";
}
echo "<input type=hidden name=bruker value=".$bruker.">\n";
echo "<input type=hidden name=trap value=$trap>";
echo "<input type=submit value=Reset>";
echo "</form>";

##################################################
# En funksjon som skriver ut en drop-down
# liste som inneholder alle varseltypene som 
# er i databasen.
##################################################
function lagDropDown($array,$name) {
global $varseltype;
echo "<select name=$name>\n";
foreach ($array as $element) {
if ($element == "mail") {
echo "<option value=".$varseltype[$element]." selected>".$element."</option>\n";
} else {
echo "<option value=".$varseltype[$element].">".$element."</option>\n";
}
}
echo "</select>\n";
}


?>

</body></html>
