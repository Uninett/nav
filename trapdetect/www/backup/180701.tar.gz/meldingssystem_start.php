<html><body>

<p><b>Velkommen til varslingsregistreringen</b></p>

<p>Hva vil du gj�re?</p>

<?php
echo "<form action=meldingssystem.php?bruker=$bruker method=\"POST\">\n";
echo "<input type=submit value=\"Ny varsling\">&nbsp;Legg til varsling for ny trap.\n";
echo "</form>\n";

echo "<form action=meldingssystem_rediger.php?bruker=$bruker method=\"POST\">\n";

$dbh = mysql_connect("localhost", "nett", "stotte") or die ("Kunne ikke �pne connection til databasen.");

##################################################
# Henter alle varslingstyper fra databasen, 
# legger de i et array for senere bruk.
##################################################
mysql_select_db("trapdetect", $dbh);

$result = mysql_query("select * from varseltype");
while ($svar = mysql_fetch_row($result)) {
  $varseltype[$svar[1]] = $svar[0];
}
$type = array_keys($varseltype);

##################################################

mysql_select_db("manage",$dbh);
# Finner brukerid
$res=mysql_query("select id,sms from user where user='$bruker'");
$brukerid = mysql_fetch_row($res);
$sms = $brukerid[1];

# Finner alle traps som brukeren abonnerer p� varsling p�
mysql_select_db("trapdetect",$dbh);
$sporring="select trapid,syknavn from varsel,trap where userid=$brukerid[0] and trapid=trap.id group by trapid order by syknavn";
$res=mysql_query($sporring);

$res2=mysql_query("select trapid,syknavn from unntak,trap where userid=$brukerid[0] and trapid=trap.id group by trapid order by syknavn");

if (mysql_num_rows($res) == 0 and mysql_num_rows($res2) == 0) {
  echo "Du abonnerer forel�pig ikke p� noe varsel";
} else {
  echo "<select name=trap>";
  while ($row=mysql_fetch_row($res)) {
    $traps[$row[0]] = $row[1];
  }
  while ($row=mysql_fetch_row($res2)) {
    $traps[$row[0]] = $row[1];
  }
  $keys = array_keys($traps);
  foreach($keys as $key) {
    echo "<option value=$key>$traps[$key]";
  }
  
  echo "</select>";
  
  $sporring="select trapid from varsel where userid=$brukerid[0]";
  
  echo "<input type=submit value=\"Rediger eksisterende varsling\"><br>Velg en av de varslene du allerede abonnerer p�, og trykk p� knappen for � redigere.\n";
  echo "</form>";
}

############################################################
# Skriver ut oversikt over alle abonnement som brukeren har
############################################################
print "Oversikt over de forskjellige varseltypene du har<br>\n";
$unntak = array();
$keys = array_keys($traps);

print "<form action=meldingssystem4.php type=\"POST\">";

print "<table cellspacing=2 border=0>";
foreach($keys as $key) {
  print "<tr><td>";
  print "<b>$traps[$key]:</b></td></tr>";
  $sporring="select * from varsel where userid=$brukerid[0] and trapid=$key order by kat,ukat";
  $res = mysql_query($sporring);
  
# Henter alle innlegg som ligger under denne trap og brukerid
  while ($row=mysql_fetch_array($res)) {
    print "<tr><td>&nbsp;</td><td>$row[kat]</td><td>$row[ukat]</td><td>\n";
# Hvis begge er definert er det en underkategori
    if ($row[kat] && $row[ukat]) {
      lagDropDown($type,"ukat:$row[kat],$row[ukat]",$row[vtypeid]);
    } elseif ($row[kat]) { 
# Hvis ikke er det en kategori
      lagDropDown($type,"kat:$row[kat]",$row[vtypeid]);
    } else { 
# Det er en trap uavhengig av enheter
      lagDropDown($type,"spesial",$row[vtypeid]);
    }
    print "</td></tr>\n";
  }

  $sporring="select manage.nettel.sysname,nettelid,vtypeid,status from manage.nettel,unntak where userid=$brukerid[0] and trapid=$key and manage.nettel.id=nettelid";
  $res=mysql_query($sporring);
# Henter alle innlegg som ligger i unntak-tabellen
  while ($row=mysql_fetch_array($res)) {
# Hvis det er en pluss s� skal det kunne velges varseltype
    if ($row[status] == "pluss") {
      print "<tr><td>&nbsp;</td><td>$row[sysname]</td><td>$row[nettelid]</td><td>\n";
      lagDropDown($type,"enhet:$row[sysname]",$row[vtypeid]);
      print "</tr>\n";
    } else {
# Lagrer alle unntakene.
      array_push($unntak,$row[sysname]);
    }
  }
  print "<tr><td>&nbsp;</td></tr>";
}
print "</table>";
foreach ($unntak as $element) {
  print "<input type=hidden name=unntak[] value=$element>\n";
}
print "</form>";

##################################################
# En funksjon som skriver ut en drop-down
# liste som inneholder alle varseltypene som 
# er i databasen.
##################################################
function lagDropDown($array,$name,$vtype) {
  global $varseltype,$sms;
  echo "<select name=$name>\n";
  foreach ($array as $element) {
    if ($varseltype[$element] == $vtype) {
      echo "<option value=".$varseltype[$element]." selected>".$element."</option>\n";
    } elseif (preg_match("/sms/",$element)) {
      if ($sms == 'Y') {
	echo "<option value=".$varseltype[$element].">".$element."</option>\n";
      }
    } else {
      echo "<option value=".$varseltype[$element].">".$element."</option>\n";
    }
  }
  echo "</select>\n";
}


?>
</body></html>