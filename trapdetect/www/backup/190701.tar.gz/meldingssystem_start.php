<html><body>

<p><h2>Velkommen til varslingsregistreringen</h2></p>

<p><u>Hva vil du gj�re?</u></p>

<?php
echo "<form action=meldingssystem.php?bruker=$bruker method=\"POST\">\n";
echo "<input type=submit value=\"Ny varsling\">&nbsp;Legg til nytt abonnement.\n";
echo "</form>\n";

print "<hr width=450 align=left>";

print "<P><B>REDIGERING AV ABONNEMENT</B></P>\n";
echo "<form action=meldingssystem_rediger.php?bruker=$bruker method=\"POST\">\n";

$dbh = mysql_connect("localhost", "nett", "stotte") or die ("Kunne ikke �pne connection til databasen.");

##################################################
# Henter alle varslingstyper fra databasen, 
# legger de i et array for senere bruk.
##################################################
mysql_select_db("trapdetect", $dbh);

$result = mysql_query("select * from varseltype");
while ($svar = mysql_fetch_row($result)) {
  $varseltype[$svar[1]] = $svar[0];
}
$type = array_keys($varseltype);

##############################
# Finner brukerid
##############################
mysql_select_db("manage",$dbh);
$res=mysql_query("select id,sms from user where user='$bruker'");
$brukerid = mysql_fetch_row($res);
$sms = $brukerid[1];

############################################################
# Finner alle traps som brukeren abonnerer p� varsling p�
############################################################
mysql_select_db("trapdetect",$dbh);
$sporring="select trapid,syknavn from varsel,trap where userid=$brukerid[0] and trapid=trap.id group by trapid order by syknavn";
$res=mysql_query($sporring);

$res2=mysql_query("select trapid,syknavn from unntak,trap where userid=$brukerid[0] and trapid=trap.id group by trapid order by syknavn");

if (mysql_num_rows($res) == 0 and mysql_num_rows($res2) == 0) {
  echo "Du abonnerer forel�pig ikke p� noe";
} else {
  echo "<select name=trap>";
  while ($row=mysql_fetch_row($res)) {
    $traps[$row[0]] = $row[1];
  }
  while ($row=mysql_fetch_row($res2)) {
    $traps[$row[0]] = $row[1];
  }
##############################
# Skriver dropdown-menyen
# for redigering
##############################
  $keys = array_keys($traps);
  foreach($keys as $key) {
    echo "<option value=$key>$traps[$key]";
  }
  
  echo "</select>";
  
  echo "<input type=submit value=\"Rediger eksisterende abonnement\"><br>Velg en av de abonnementene du allerede abonnerer p�, og trykk p� knappen for � redigere.\n";
  echo "</form>";

  print "<hr width=450 align=left>";
##############################
# Skriver dropdown-menyen
# for sletting
##############################
  print "<p><B>SLETTING AV ABONNEMENT</B></p>\n";
  print "<form action=meldingssystem_slett.php method=POST>";
  print "<select name=trapid>";
  foreach($keys as $key) {
    echo "<option value=$key>$traps[$key]";
  }
  
  echo "</select>";
  echo "<input type=hidden name=brukerid value=$brukerid[0]>";
  echo "<input type=hidden name=bruker value=$bruker>";
  echo "<input type=submit value=\"Slett abonnement\"><br>Velg det abonnementet som skal slettes og trykk p� <b>Slett abonnement</b>.\n";
  echo "</form>";

  print "<hr width=450 align=left>";
############################################################
# Skriver ut oversikt over alle abonnement som brukeren har
############################################################
  print "<p><b>REDIGERING AV VARSELTYPE</b></p>\n";
  print "Skift varslingstype p� de kategorier/underkategorier/enheter du vil og trykk <b>Lagre endringer</b>\n";
  $unntak = array();
  $keys = array_keys($traps);

  print "<form action=meldingssystem4.php method=\"POST\">\n";
  print "<table cellspacing=2 border=0>";
  foreach($keys as $key) {
    print "<tr><td>";
    print "<b>$traps[$key]:</b></td><td>";
#    lagSlettBoks($key,$traps[$key]);
    print "</td></tr>";
    $sporring="select * from varsel where userid=$brukerid[0] and trapid=$key order by kat,ukat";
    $res = mysql_query($sporring);
  
# Henter alle innlegg som ligger under denne trap og brukerid
    while ($row=mysql_fetch_array($res)) {
      print "<tr><td>&nbsp;</td><td>$row[kat]</td><td>$row[ukat]</td><td>\n";
# Hvis begge er definert er det en underkategori
      if ($row[kat] && $row[ukat]) {
	lagDropDown($type,"$key:ukat:$row[kat],$row[ukat]",$row[vtypeid]);
      } elseif ($row[kat]) { 
# Hvis ikke er det en kategori
	lagDropDown($type,"$key:kat:$row[kat]",$row[vtypeid]);
      } else { 
# Det er en trap uavhengig av enheter
	lagDropDown($type,"$key:spesial",$row[vtypeid]);
      }
      print "</td></tr>\n";
    }

    $sporring="select manage.nettel.sysname,nettelid,vtypeid,status from manage.nettel,unntak where userid=$brukerid[0] and trapid=$key and manage.nettel.id=nettelid order by manage.nettel.sysname";
    $res=mysql_query($sporring);
# Henter alle innlegg som ligger i unntak-tabellen
    while ($row=mysql_fetch_array($res)) {
# Hvis det er en pluss s� skal det kunne velges varseltype
      if ($row[status] == "pluss") {
	print "<tr><td>&nbsp;</td><td>$row[sysname]</td><td>$row[nettelid]</td><td>\n";
	lagDropDown($type,"$key:enhet:$row[sysname]",$row[vtypeid]);
	print "</tr>\n";
      } else {
# Lagrer alle unntakene.
	array_push($unntak,$row[sysname]);
      }
    }
    print "<tr><td>&nbsp;</td></tr>\n";
  }
  print "</table>\n";

  print "<input type=hidden name=bruker value=$bruker>\n";
  print "<input type=submit name=submit_form value=\"Lagre endringer\">\n";
  print "</form>\n";
}
##################################################
# En funksjon som skriver ut en drop-down
# liste som inneholder alle varseltypene som 
# er i databasen.
##################################################
function lagDropDown($array,$name,$vtype) {
  global $varseltype,$sms,$unntak;

  echo "<select name=$name>\n";
  foreach ($array as $element) {
    if ($varseltype[$element] == $vtype) {
      echo "<option value=".$varseltype[$element]." selected>".$element."</option>\n";
    } elseif (preg_match("/sms/",$element)) {
      if ($sms == 'Y') {
	echo "<option value=".$varseltype[$element].">".$element."</option>\n";
      }
    } else {
      echo "<option value=".$varseltype[$element].">".$element."</option>\n";
    }
  }
  echo "</select>\n";

  foreach ($unntak as $element) {
    print "<input type=hidden name=unntak[] value=$element>\n";
  }
}

########################################
# En funksjon som lager en slettboks
# Spesifikk for denne siden
########################################
function lagSlettBoks($trapid,$trapname) {
  global $bruker,$brukerid;
  print "\n\t<form action=meldingssystem_slett.php method=\"POST\">\n";
  print "\t<input type=submit name=$trapid value=Slett>\n";
  print "\t<input type=hidden name=trapid value=$trapid>\n";
  print "\t<input type=hidden name=trapname value=$trapname>\n";
  print "\t<input type=hidden name=bruker value=$bruker>\n";
  print "\t<input type=hidden name=brukerid value=$brukerid[0]>\n";
  print "\t</form>\n";
}
?>
</body></html>