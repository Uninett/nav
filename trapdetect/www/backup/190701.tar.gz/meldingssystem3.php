<html><body>

<?php

$dbh = mysql_connect("localhost", "nett", "stotte") or die ("Kunne ikke �pne connection til databasen.");

echo "<p><h3>STEG 3</h3>Velg varslingstype for de valgte enheter for <b>$trap</b> bruker <b>$bruker</b></p>\n";

echo "<form action=meldingssystem.php method=\"POST\">";
echo "<input type=hidden name=bruker value=$bruker>";
echo "<input type=submit value=\"Tilbake til steg 1\">\n";
echo "</form><br>\n";

$borders=0;
$unntak = array(); # Holder styr p� alt som ikke skal v�re med 

$postvars = $HTTP_POST_VARS;
$keys = array_keys($postvars);
#foreach ($keys as $key) {
#	if (preg_match("/list/",$key)) {
#		foreach ($postvars[$key] as $temp) {
#			echo "$key -> $temp<br>\n";
#		}
#	} else {
#		echo "$key -> $postvars[$key]<br>\n";
#	}
#}

########################################
# Finner ut om bruker kan velge sms.
########################################
mysql_select_db("manage", $dbh);
$sporring = "select sms from user where user='$bruker'";
$res = mysql_query($sporring);
$temp = mysql_fetch_row($res);
$sms = $temp[0];

#################
# Finner trapid
#################
mysql_select_db("trapdetect", $dbh);
$sporring="select id from trap where syknavn='$trap'";
$res = mysql_query($sporring);
$temp = mysql_fetch_row($res);
$trapid = $temp[0];

##################################################
# Henter alle enhetene som evt. eksisterer fra f�r
##################################################
$eksisterer_ukat = array();
$eksisterer_kat = array();
$eksisterer_enhet = array();
$sporring = "select varsel.kat,varsel.ukat,varsel.vtypeid from varsel,manage.user where userid=manage.user.id and manage.user.user='$bruker' and trapid=$trapid";
$res = mysql_query($sporring);
while ($temp = mysql_fetch_row($res)) {
  if ($temp[0] && $temp[1]) {
    $eksisterer_ukat[$temp[0]][$temp[1]] = $temp[2];
  } elseif ($temp[0]) {
    $eksisterer_kat[$temp[0]] = $temp[2];
  }
}

$sporring = "select manage.nettel.sysname,unntak.vtypeid from unntak,manage.nettel,manage.user where userid=manage.user.id and manage.user.user='$bruker' and trapid=$trapid and nettel.id=unntak.nettelid and unntak.status='pluss'";
$res = mysql_query($sporring);
while ($temp = mysql_fetch_row($res)) {
  $eksisterer_enhet[$temp[0]] = $temp[1];
}

##################################################
# Legger alle variablene i forskjellige array
# alt etter tilh�righet.
# kategorier: hvis en kat er valgt havner den her, key=kat
# underkat: hvis en underkat er valgt, havner den her, key=kat
# list: alle enhetene som er valgt, key=kat
##################################################

$uarr = array();
$arr = array();
$eier = array();
foreach ($keys as $var) {
  if (preg_match("/kat_(.+)/",$var,$matches)) { 
# Kategorivalg (ikke underkategorier)
    $kategorier[$matches[1]]++;
  } elseif (preg_match("/list_(.+)/",$var,$matches)) { 
# Valg fra listene
    $arr = array();
    foreach ($postvars[$matches[0]] as $temp) {
      array_push ($arr, $temp);
    }
    $list[$matches[1]] = $arr;
  } elseif (preg_match("/eier/",$var)) {
    array_push($eier,$postvars[$var]);
  } elseif (preg_match("/(.+)_(.+)/",$var,$matches) or preg_match("/ukat_(.+)/",$var,$matches)) { 
# Bare underkat igjen
    $arr = array();
    if ($underkat[$matches[1]]) { 
# Tidligere underkat eksisterer
      $arr = $underkat[$matches[1]];
      array_push($arr,$matches[2]);
      $underkat[$matches[1]] = $arr;
    } else {
      array_push($arr,$matches[2]);
      $underkat[$matches[1]] = $arr;
    }
  }
}


##################################################
# Henter alle varslingstyper fra databasen, 
# legger de i et array for senere bruk.
##################################################
$result = mysql_query("select * from varseltype");
while ($svar = mysql_fetch_row($result)) {
  $varseltype[$svar[1]] = $svar[0];
}
$type = array_keys($varseltype);


echo "Velg varslingstype for de forskjellige kategoriene/underkategoriene/enhetene";
echo "<form action=meldingssystem4.php method=\"POST\">\n";

##################################################
# Her begynner utskriving av data
##################################################

echo "<table border=$borders cellspacing=10>\n";

##################################################
# F�rst skrives alle valgte kategorier ut
##################################################

if ($kategorier) {
  print "<br>\n";
  $keys = array_keys($kategorier);
  foreach ($keys as $key) {
    echo "<tr valign=top><td>";
    echo $key;
    echo "</td><td>\n";
    if ($eksisterer_kat[$key]) {
      lagDropDown2($type,"kat:".$key,$eksisterer_kat[$key]);
    } else {
      lagDropDown($type,"kat:".$key);
    }
    if ($underkat[$key]) {
      echo "</td><td>\n";
      skrivUnderkategorier($key);
      $underkat[$key] = "";
    }
    if ($list[$key]) {
      echo "</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>\n";
      skrivEnkeltenheter($key,"N",1);
    }
    if ($list) {
      foreach (array_keys($list) as $temp) {
	if (preg_match("/$key.+/",$temp)) {
	  echo "</td><td>";
	  skrivEnkeltenheter($key,"N",1);
	}
      }
    }
    echo "</td></tr>";
  }
} else {
  echo "Ingen kategorier valgt<br>\n";
}

##################################################
# Deretter skrives alle valgte underkategorier
# utenom de som allerede er skrevet ut ovenfor.
# Dette vil skje dersom en kategori ikke er
# valgt, mens noen underkategorier er valgt.
##################################################

if ($underkat) {
  $ukats = array_keys($underkat);
  foreach ($ukats as $underkategorier) {
    if ($underkat[$underkategorier]) {
      echo "<tr><td valign=top>\n";
      if (!$kategorier[$underkategorier]) { 
# formatering
	echo "$underkategorier</td><td>&nbsp;</td><td>";
      }
      skrivUnderkategorier($underkategorier);
      echo "</td></tr>";
    }
  }
}

##################################################
# S� skrives alle enkeltenheter ut som ikke er
# skrevet ut enn�.
#
# Dette vil skje hvis det er enheter som er valgt
# uten at hverken kategorien eller underkategorien
# er valgt. Alts� det laveste niv�et man kan
# velge enkeltenheter p�.
##################################################

if ($list) {
  $keys = array_keys($list);
  foreach ($keys as $key) {
    if ($list[$key]) {
      echo "<tr><td valign=top>\n";
      echo $key."</td><td>&nbsp;</td><td>\n";
      skrivEnkeltenheter($key,"Y",1);
      echo "</td></tr>";
    }
  }
}
echo "</table>\n";

##################################################
# Utskriving er ferdig, sender data til neste
# side med submit.
##################################################

foreach($unntak as $element) {
  echo "<input type=hidden name=$trapid:unntak[] value=$element>\n";
}
echo "<input type=hidden name=bruker value=".$bruker.">\n";
echo "<input type=submit value=\"G� videre\">";
echo "</form>\n";


############################################################
####################     FUNKSJONER     ####################
############################################################

##################################################
# En funksjon som skriver ut underkategorier som
# tilh�rer kategorien $key.
#
# Metoden lager en egen tabell. Ta hensyn til dette, 
# og gj�r klar med <td> og </td> f�r og etter 
# metoden kalles.
##################################################
function skrivUnderkategorier($key) {
  global $underkat,$list,$type,$kategorier, $borders, $unntak;

  echo "\n\t<table cellspacing=5 border=$borders>\n";
  foreach ($underkat[$key] as $ukat) {
# Hvis kat er satt er dette unntak
    if ($kategorier[$key]) {
      echo "\t<tr><td>";
      echo $ukat."</td><td>Ikke med</td>\n";
      array_push($unntak,$key.",".$ukat);

      $listvar = $key."_".$ukat;
      if ($list[$listvar]) { 
# finner valgte enheter
	echo "\t<td>\n";
# Siden dette er unntak fra unntak s� skal de v�re med.
	skrivEnkeltenheter($listvar,"Y",0);
#				echo "\t</td>\n";
      }
    } else { 
# Dette skal legges til
      echo "\t<tr><td>";
      echo $ukat."</td><td>";
      if ($eksisterer_ukat[$key][$ukat]) {
	lagDropDown2($type, "ukat:".$key.",".$ukat,$eksisterer_ukat[$key][$ukat]);
      } else {
	lagDropDown($type, "ukat:".$key.",".$ukat);
      }
      echo "\t</td>\n";

      $listvar = $key."_".$ukat;
      if ($list[$listvar]) { 
# finner valgte enheter alts� unntak
	echo "\t<td>\n";
	skrivEnkeltenheter($listvar,"N",0);
#				echo "\t</td>\n";
      }
    }
  }
  echo "\t</tr></table>";
}

##################################################
# En funksjon som skriver ut enheter som
# tilh�rer kategorien $key, og som tar inn en
# boolsk variabel $med. Hvis denne er satt til
# "Y", vil enheten f� valg om varseltype.
#
# Metoden lager en egen tabell. Ta hensyn til dette, 
# og gj�r klar med <td> og </td> f�r og etter 
# metoden kalles.
##################################################
function skrivEnkeltenheter($key,$med,$tabell) {
  global $list,$type, $borders,$unntak;

  if ($tabell == 1) {
    echo "\n\t\t<table border=$borders>";
    if ($med == "Y") {
      foreach ($list[$key] as $enhet) {
	echo "\n\t\t<tr><td>";
	echo $enhet;
	echo "</td><td>";
	if ($eksisterer_enhet[$enhet]) {
	  lagDropDown2($type, "enhet:".$enhet,$eksisterer_enhet[$enhet]);
	} else {
	  lagDropDown($type, "enhet:".$enhet);
	}
	echo "</td></tr>";
      }
      $list[$key] = "";
    } else {
# Siden dette er unntak fra tillegg s� skal de ikke v�re med.
      if ($list[$key]) {
	foreach ($list[$key] as $enhet) { 
# Alle som eksplisitt har denne key.
	  echo "\n\t\t<tr><td>";
	  echo $enhet;
	  echo "</td><td>ikke med</td></tr>\n";
	  array_push($unntak,$enhet);
	}
	$list[$key] = "";
      }
# Sjekker alle andre for � se om det er noen underkategorienheter som skal v�re med
      foreach (array_keys($list) as $temp) {
	if (preg_match("/$key.+/",$temp)) {
	  if ($list[$temp]) {
	    foreach ($list[$temp] as $enhet) {
# Alle som implisitt har denne key.
	      echo "\t\t<tr><td>";
	      echo $enhet;
	      echo "</td><td>ikke med</td></tr>\n";
	      array_push($unntak,$enhet);
	    }
	    $list[$temp] = "";
	  }
	}
      }
    }
    echo "\t\t</table>\n";
  } elseif ($list[$key]) {
# Hvis den ikke er tom
    if ($med == "Y") {
      $teller = 0;
      foreach ($list[$key] as $enhet) {
	if ($teller != 0) {
	  echo "\n\t\t<tr><td>&nbsp;</td><td>&nbsp;</td><td>";
	}
	$teller++;
	echo $enhet;
	echo "</td><td>";
	if ($eksisterer_enhet[$enhet]) {
	  lagDropDown2($type, "enhet:".$enhet,$eksisterer_enhet[$enhet]);
	} else {
	  lagDropDown($type, "enhet:".$enhet);
	}
	echo "</td></tr>";
      }
      $list[$key] = "";
    } else {
# Siden dette er unntak fra tillegg s� skal de ikke v�re med.
      $teller = 0;
      foreach ($list[$key] as $enhet) { 
# Alle som eksplisitt har denne key.
	if ($teller != 0) {
	  echo "\n\t\t<tr><td>&nbsp;</td><td>&nbsp;</td><td>";
	}
	$teller++;
	echo $enhet;
	echo "</td><td>ikke med</td></tr>\n";
	array_push($unntak,$enhet);
      }
      $list[$key] = "";
# Sjekker alle andre for � se om det er noen underkategorienheter som skal v�re med
      foreach (array_keys($list) as $temp) {
	if (preg_match("/$key.+/",$temp)) {
	  if ($list[$temp]) {
	    foreach ($list[$temp] as $enhet) { 
# Alle som implisitt har denne key.
	      echo "\t\t<tr><td>";
	      echo $enhet;
	      echo "</td><td>ikke med</td></tr>\n";
	      array_push($unntak,$enhet);
	    }
	    $list[$temp] = "";
	  }
	}
      }
    }
  }
}

##################################################
# En funksjon som skriver ut en drop-down
# liste som inneholder alle varseltypene som 
# er i databasen.
##################################################
function lagDropDown($array,$name) {
  global $varseltype,$sms,$trapid;
  echo "<select name=$trapid:$name>\n";
  foreach ($array as $element) {
    if ($element == "mail") {
      echo "<option value=".$varseltype[$element]." selected>".$element."</option>\n";
    } elseif (preg_match("/sms/",$element)) {
      if ($sms == 'Y') {
	echo "<option value=".$varseltype[$element].">".$element."</option>\n";
      }
    } else {
      echo "<option value=".$varseltype[$element].">".$element."</option>\n";
    }
  }
  echo "</select>\n";
}

function lagDropDown2($array,$name,$vtype) {
  global $varseltype,$sms,$trapid;
  echo "<select name=$trapid:$name>\n";
  foreach ($array as $element) {
    if ($varseltype[$element] == $vtype) {
      echo "<option value=".$varseltype[$element]." selected>".$element."</option>\n";
    } elseif (preg_match("/sms/",$element)) {
      if ($sms == 'Y') {
	echo "<option value=".$varseltype[$element].">".$element."</option>\n";
      }
    } else {
      echo "<option value=".$varseltype[$element].">".$element."</option>\n";
    }
  }
  echo "</select>\n";
}

?>

</body></html>