<html><body>

<?php

# Kobler til database.
#echo "<p>Oppretter kontakt med databasen...";
$dbh = mysql_connect("localhost", "nett", "stotte") or die ("Kunne ikke �pne connection til databasen.");
#echo "ok</p>\n";

##################################################
# Henter n�dvendige data; brukerid
##################################################
mysql_select_db("manage", $dbh);
$resultat = mysql_query("select id from user where user='".$bruker."'");
$userid = mysql_fetch_row($resultat);
##################################################

$postvars = $HTTP_POST_VARS;
$keys = array_keys($postvars);
$trapvars = array();

foreach ($keys as $key) {
  preg_match("/^(\d+):(.+)/",$key,$matches);
  # Legger inn det arrayet som skal inneholde postvars til denne trapen
  if (!$trapvars[$matches[1]]) {
    $tempvars = array();
  } else {
    $tempvars = $trapvars[$matches[1]];
  }

  if (preg_match("/(list|unntak)/",$key)) {
    $tempvars[$matches[2]] = $postvars[$key];
    foreach ($postvars[$key] as $temp) {
#      echo "$key -> $temp<br>\n";
    }
  } elseif(!preg_match("/bruker/",$key)) {
    $tempvars[$matches[2]] = $postvars[$key];
#    echo "$key -> $postvars[$key]<br>\n";
  } else {
#    echo "$key -> $postvars[$key]<br>\n";
  }

  $trapvars[$matches[1]] = $tempvars;
}

$keys = array_keys($trapvars);
foreach ($keys as $key) {
  if ($key) {
#    print "KEY: $key<br>\n";
    $temp = $trapvars[$key];
    legginn($key,$temp);
    $tempkeys = array_keys($temp);
    foreach ($tempkeys as $tempkey) {
#      print "$tempkey -> $temp[$tempkey]<br>\n";
    }
  }
}


##################################################
# Funksjon som legger inn alle data om et varsel
# Tar inn navn p� trap, trapid og arrayet som
# inneholder alle variable.
##################################################
function legginn($trapid,$variable) {
  global $userid,$dbh;

#  print "Funksjon legginn f�r inn $trapid, $variable<br>\n";

  mysql_select_db("trapdetect", $dbh);
  $resultat = mysql_query("select syknavn from trap where id=$trapid");
  $trapname = mysql_fetch_row($resultat);

##################################################
# Parser variable og lager sp�rringer.
##################################################

# Leter f�rst etter unntak som vi m� ha for � lage sp�rringer.
  $enhetunntak = array();

  if ($variable["unntak"]) {
    foreach ($variable["unntak"] as $element) {
      if (preg_match("/(.+),(.+)/",$element,$matches)) {
# Dette er et underkategoriunntak
# M� finne alle enheter som er med i denne kombinasjonen av kat og ukat og legge dem i unntak-tabellen.
	mysql_select_db("manage", $dbh);
	$sporring = "select sysname from nettel where kat='$matches[1]' and underkat='$matches[2]'";
	$res = mysql_query($sporring);
	while ($row=mysql_fetch_row($res)) {
# Hvis den finnes som enhet som skal legges til m� vi fjerne denne.
	  if (!$variable["enhet:$row[0]"]) {
	    array_push($enhetunntak,$row[0]);
	  } else {
	    print "Enheten eksisterer ogs� som tillegg: $row[0]<br>\n";
	  }
	}
      } else { 
# Dette er en enhet
	array_push($enhetunntak,$element);
      }
    }
  }

################################################################################
# Under sp�rringene behandler jeg unntak slik:
# Hvis det bare er en kategori uten unntak p� underkategoriene, lager jeg 
# sp�rringen direkte, med bare kat satt i varsel.
# Hvis det er en kategori MED unntak p� underkategoriene, er dette allerede
# i unntak-arrayet, s� det bryr jeg meg ikke om.
# Hvis det er en underkategori uten kategori, legger jeg den direkte inn
# i varsel UTEN kat.
#
# Dette er viktig � forst� for uthenting av varsel.
################################################################################
  $keys = array_keys($variable);

  $sporringer = array();
  mysql_select_db("trapdetect", $dbh);
  foreach ($keys as $element) {
    if (preg_match("/^kat:(.+)/",$element,$matches)) { 
# Vi har funnet en hovedkategori
      $sporring = "insert into varsel (userid,trapid,kat,vtypeid) values (".$userid[0].",".$trapid.",'".$matches[1]."',".$variable[$matches[0]].")";
      array_push($sporringer,$sporring);
    } elseif (preg_match("/^ukat:(.+),(.+)/",$element,$matches)) { 
# Vi har funnet en underkategori
      $sporring = "insert into varsel (userid,trapid,kat,ukat,vtypeid) values (".$userid[0].",".$trapid.",'".$matches[1]."','".$matches[2]."',".$variable[$matches[0]].")";
      array_push($sporringer,$sporring);
    } elseif (preg_match("/enhet:(.+)/",$element,$matches)) { 
# Vi har funnet en enhet som skal legges til.
      mysql_select_db("manage", $dbh);
      $res = mysql_query("select id from nettel where sysname='".$matches[1]."'");
      if (mysql_num_rows($res) == 0) { 
# Noe gikk galt, kanskje med sysname
	$matches[1] = preg_replace("/_/",".",$matches[1]); 
# Skifter underscore med punktum
	$res = mysql_query("select id from nettel where sysname='".$matches[1]."'"); 
# Ny sp�rring kj�res
      }
      $enhet = mysql_fetch_row($res);
      $sporring = "insert into unntak (userid,trapid,nettelid,vtypeid,status) values (".$userid[0].",".$trapid.",".$enhet[0].",".$variable[$matches[0]].",'pluss')";
      array_push($sporringer,$sporring);
    } elseif (preg_match("/spesial/",$element)) { 
# Denne kommer av traps uavhengige av enheter
      $sporring = "insert into varsel (userid,trapid,vtypeid) values (".$userid[0].",".$trapid.",".$variable["spesial"].")";
      array_push($sporringer,$sporring);
    }
  }

##################################################
# Ferdig med alle elementene i inputstrengen,
# trenger n� � skrive alle unntak for enheter som
# er i $enhetunntak til unntak-tabellen.
##################################################
  foreach ($enhetunntak as $innlegg) {
    mysql_select_db("manage", $dbh);
    $res = mysql_query("Select id from nettel where sysname='".$innlegg."'");
    $enhet = mysql_fetch_row($res);
    $sporring = "insert into unntak (userid,trapid,nettelid,status) values (".$userid[0].",".$trapid.",".$enhet[0].",'minus')";
    array_push($sporringer,$sporring);
  }

######################################################################
# Legger alle sp�rringene inn i databasen.
#
# Sletter f�rst alle innlegg med samme bruker og trap som eksisterer
# fra f�r. S� legges alle innleggene inn.
######################################################################
  mysql_select_db("trapdetect", $dbh);
  mysql_query("delete from varsel where userid=".$userid[0]." and trapid=".$trapid);
  mysql_query("delete from unntak where userid=".$userid[0]." and trapid=".$trapid);
  foreach ($sporringer as $sporring) {
    echo "$sporring<br>\n";
    mysql_query($sporring);
  }

  echo "<p>Innleggene for <b>$trapname[0]</b> er n� lagt i databasen.</p>";

}

echo "<p>Trykk p� <b>Registrer ny trap</b>-knappen for � legge til et nytt abonnement eller g� tilbake til hovedsiden med � trykke <b>Til hovedsiden</b></p>";

echo "<form action=meldingssystem.php method=\"POST\">";
echo "<input type=hidden name=bruker value=$bruker>";
echo "<input type=submit value=\"Registrer ny trap\">\n";
echo "</form>\n";

echo "<form action=meldingssystem_start.php?bruker=$bruker method=\"POST\">";
echo "<input type=submit value=\"Til hovedsiden\">\n";
echo "</form>\n";


?>
</body></html>
