<!-- Tar inn fire variable, $name, $antdager, $oid og $fname -->

<?php require('include.inc'); ?>

<?php tittel("Meldinger ang�ende $name med trap'en $oid") ?>

Her er oversikt over de meldingene som har kommet inn fra <?php echo $name; ?> av type <?php echo $oid;?>. 

<?php topptabell(statistikk) ?>

<?php

$dagteller = 0;
$tekst;
$dag = 0;
$arrayteller = 0;

while ($dagteller <= $antdager) {

	$filename;

	if ($dagteller == 0) {
		if ($fname) {
			$filename = "/home/trapdet/log/$fname";
			$temp = preg_match("/\d{2}/", $fname, $dager);
			$dag = $dager[0];
#			print "$dag<br>\n";
		} else {
			$filename = "/home/trapdet/log/history";
			$dag = date("d")-$dagteller;
		}

	} else {
		# Finner navn til fila.
		$dato = date("dmy", mktime(0,0,0,date("m"),date("d")-$dagteller,date("Y")));
		$filename = "/home/trapdet/log/history$dato";
		$dag = date("d", mktime(0,0,0,date("m"),date("d")-$dagteller,date("Y")));
	}

	if (is_file ($filename)) {
		$innhold = file($filename);

#		print "Henter info fra $filename<br>\n";

		$teller = 0;
		$funnet = 0;
		$streng = "";
		$d = 0;

		while($innhold[$teller]) {
			if (preg_match("/$name/", $innhold[$teller]) && preg_match("/$oid/", $innhold[$teller])) {
#				print "Kicker p� $innhold[$teller]<br>\n";
				$d = $innhold[$teller-1];

				# Filtrerer vekk datoer som ikke skal v�re med.
				$temp = preg_match("/^\d+\/(\d+)\/\d+/", $d, $match);
#				print "Dag = $dag, Match = $match[1]<br>\n";

				if ($match[1] == $dag) {
#					print "Funnet match p� dato<br>\n";
					$funnet = 1;
				} else {
#					print "Funnet mismatch p� dato<br>\n";
					$funnet = 0;
				}

			} elseif (preg_match("/^-/", $innhold[$teller]) && $funnet) {
				$streng .= $innhold[$teller-2] . "<br>\n";
				$streng .= $innhold[$teller-1] . "<br>\n";
				$streng .= "-<br>\n";
				$funnet = 0;
				$tekst[$arrayteller] = $streng;
				$arrayteller++;
				$streng = "";
			} elseif ($funnet) {
				$streng .= $innhold[$teller-2] . "<br>\n";
			}
			$teller++;
		}

	} else {
		print "Finner ikke filen $filename\n";
	}

	$dagteller++;
}

$antall = sizeof ($tekst);
print "<p><h3>Meldinger mottatt fra $name ang�ende $oid-trap</h3></p>";
print "<p><b>Antall elementer: $antall</b></p>\n";

for ($i=0; $i<$antall; $i++) {
	print $tekst[$i];
}

?>

<?php bunntabell() ?>






