<?php require('include.inc'); ?>

<?php tittelspesial("Slett") ?>

SLETTER...

<?php topptabell(diverse) ?>

<?php

$teller = 0;

for ($i=0;$i<$antall;$i++) {
	$b = b.$i;
	if (${$b}) {
#		echo "Boks $i: ${$b} <br>\n";
		$liste[$teller] = ${$b}-1;
#		print "Ny verdi: $liste[$teller]<br>\n";
		$teller++;
	}
}

$antall = sizeof($liste);

function slettfrasick($liste) {

	$sick = "/home/trapdet/sick";

	# Hiver fila i et array
	$innhold = file($sick);
	$handle = fopen($sick, "w");

	$listeteller = 0;
	$historyteller = 0;

	$slett = 0;
	$teller = 0;

	# Sletter fra sick-fila, hiver det som er slettet i et array
	# for sammenligning og sletting fra history. 
	while ($innhold[$teller]) {
		$linjestart = $liste[$listeteller];

		if ($teller == $linjestart) {
			# Skal slette fra fila
			$slett = 1;
			$listeteller++;
			$historyslett[$historyteller] = $innhold[$teller];
			$historyteller++;

#			print "$innhold[$teller]<br>\n";
		} elseif (($slett) && (preg_match("/^-/", $innhold[$teller]))) {
			$slett = 0;
#			print "$innhold[$teller]<br><br>\n";

			$historyslett[$historyteller] = $innhold[$teller];
			$historyteller++;
		} elseif ($slett) {
			# Do nothing
			$historyslett[$historyteller] = $innhold[$teller];
			$historyteller++;
#			print "$innhold[$teller]<br>\n";
		} else {
			fwrite($handle, $innhold[$teller]);
		}
		$teller++;
	}
	return $historyslett;
}

function slettfrahistory($liste) {
	$history = "/home/trapdet/log/history";

	$innhold = file($history);
	$handle = fopen($history, "w");

	$listeteller = 0;
	$teller = 0;
	while ($innhold[$teller]) {
		
		if (!($mulig) && (preg_match("/\d+\/\d+\/\d+/", $liste[$listeteller])) && ($liste[$listeteller] == $innhold[$teller])) {
			$mulig = 1;
			$next = $listeteller;
			$start = $teller;
			$listeteller++;
#			print "Sletter: $innhold[$teller]<br>\n";
		} elseif (($mulig) && (preg_match("/^-/",$liste[$listeteller]))) {
			$listeteller++;
			$mulig = 0;
#			print "Sletter: $innhold[$teller]<br>\n";
		} elseif (($mulig) && ($liste[$listeteller] == $innhold[$teller])) {
			$listeteller++;
#			print "Sletter: $innhold[$teller]<br>\n";
		} elseif (($mulig) && ($liste[$listeteller] != $innhold[$teller])) {
#			print "Skriver ut p� nytt... :<br>\n";
			for ($i = $start;$i<$teller;$i++) {
#				print "$innhold[$i]<br>\n";
				fwrite($handle,$innhold[$i]);
			}
			$mulig = 0;
			$listeteller = $next;
			fwrite($handle, $innhold[$teller]);
		} else {
			fwrite($handle, $innhold[$teller]);
		}
		$teller++;
	}	
}


function friskmeld($navn,$liste) {
	$history = "/home/trapdet/log/history";

	$innhold = file($history);
	$handle = fopen($history, "w");

	$dato = date("m/d/y-H:i:s");

	$listeteller = 0;
	$teller = 0;
	while ($innhold[$teller]) {
		if (!($mulig) && (preg_match("/\d+\/\d+\/\d+/", $liste[$listeteller])) && ($liste[$listeteller] == $innhold[$teller])) {
			$mulig = 1;
			fwrite($handle, $innhold[$teller]);
#			print "1 -> L$teller Matcher: $liste[$listeteller] = $innhold[$teller]<br>\n";
			$next = $listeteller;
			$listeteller++;
		} elseif (($mulig) && (preg_match("/^-/",$liste[$listeteller]))) {
#			print "2 -> L$teller Matcher: $liste[$listeteller] = $innhold[$teller]<br>\n";
			$listeteller++;
			fwrite($handle, "FRISKMELDT: ($navn) $dato\n");
			fwrite($handle, $innhold[$teller]);
			$mulig = 0;
		} elseif (($mulig) && ($liste[$listeteller] == $innhold[$teller])) {
			fwrite($handle, $innhold[$teller]);
#			print "3 -> Matcher: $liste[$listeteller] = $innhold[$teller]<br>\n";
			$listeteller++;
		} elseif ($mulig) {
#			print "3 -> Matcher: $liste[$listeteller] = $innhold[$teller]<br>\n";
			$mulig = 0;
			$listeteller = $next;
			fwrite($handle, $innhold[$teller]);
		} else {
			fwrite($handle, $innhold[$teller]);
		}
		$teller++;
	}	
}

if ($antall > 0) {
	if ($knapp == "slett") {
		$hliste = slettfrasick($liste);
		slettfrahistory($hliste);
	} elseif ($knapp == "friskmeld") {
		$hliste = slettfrasick($liste);
		friskmeld($navn,$hliste);
	} else {
		print "Du m� velge friskmeld eller slett<br>\n";
	}
} else {
	print "Du m� trykke p� en boks for � slette innlegg<br>\n";
}

?>

<?php bunntabell() ?>
