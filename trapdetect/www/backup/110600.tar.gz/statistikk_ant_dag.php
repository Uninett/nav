<?php require('include.inc'); ?>
<?php require('statistikk.inc'); ?>

<?php tittel("Korttidsoversikt") ?>

Korttidsoversikt som viser statistikk over enheter som har sendt traps i tidsrommet gitt. Det er bare sykmeldings-traps som er registrert, friskmeldinger blir ikke registrert.

<?php topptabell(statistikk) ?>

<?php
	echo "<p>Korttidsoversikt:\n";
	echo "<form action=statistikk_ant_dag.php method=GET>\n";
	if (!$dato) {
		$dato = date(dmy);
	}
	echo "<input type=text name=dato size=6 maxlength=6 value=$dato>\n";
	echo "<input type=submit value=Submit>\n";
	echo "</form>\n";
	echo "</p>\n";
?>

<p><center><?php print "<h3>Traps pr. enhet for $dato</h3>"; ?></center></p>

<?php 

$path = "/home/trapdet/statistikk";

# Henter info fra fil
if (preg_match("/\d{6}/",$dato)) {
	if ($dato == date("dmy")) {
		$filename = "$path/oiddag.dat";
		list ($data,$max) = lagData("ant", $filename);
		list ($imagemap, $bilde) = tegnBilde($data,$max);
		$antall = sizeof($imagemap);

		echo "<center><img src=\"gif/$bilde.gif\" usemap=\"#map\" border=0></center>\n";

		# Tegner opp imagemap
		echo "<map name=\"map\">";
		for ($i = 0; $i < $antall; $i++) {
			$navn = key ($imagemap);
			list($x,$y,$xx,$yy) = $imagemap[$navn];
			echo "<area shape=rect href=\"statistikk_oid_dag_det.php?name=$navn&date=$dato\" coords=\"$x,$y,$xx,$yy\">\n";
			next($imagemap);
		}
		echo "</map>";
	} else {
		$filename = "$path/log/oiddag.dat$dato";

		if (is_file ($filename)) {
			list ($data,$max) = lagData("ant", $filename);
			list ($imagemap, $bilde) = tegnBilde($data,$max);
			$antall = sizeof($imagemap);

			echo "<center><img src=\"gif/$bilde.gif\" usemap=\"#map\" border=0></center>\n";

			# Tegner opp imagemap
			echo "<map name=\"map\">";
			for ($i = 0; $i < $antall; $i++) {
				$navn = key ($imagemap);
				list($x,$y,$xx,$yy) = $imagemap[$navn];
				echo "<area shape=rect href=\"statistikk_oid_dag_det.php?name=$navn&date=$dato\" coords=\"$x,$y,$xx,$yy\">\n";
				next($imagemap);
			}
			echo "</map>";
		} else {
			print "Denne filen finnes ikke. Vi har bare lagret data siden ";
			if (date("dmy") > date("dmy", mktime(0,0,0,8,30,2000))) {
				$tomndsiden = date ("d M Y", mktime(0, 0, 0, date("m")-2, 1, date("Y")));
				print "$tomndsiden.<br>\n";
			} else {
				print "24 July 2000.<br>\n";
			}
		}
	}
} else {
	print "Dato m� v�re p� format ddmmyy<br>\n";
}

?>

<?php bunntabell() ?>









