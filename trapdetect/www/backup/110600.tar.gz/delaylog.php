<?php require('include.inc'); ?>

<?php tittel("ForsinketGSMlogg") ?>

Log'en som angir til hvem forsinket sms-melding er sendt ut.

<?php topptabell(diverse) ?>

	<?php

	$filename = "/home/trapdet/log/dsmslogg";

	$innhold = file($filename);

	$teller = 0;
	while($innhold[$teller]) {
	print ("$innhold[$teller]<br>");
	$teller++;
	}
	?>

<?php bunntabell() ?>
