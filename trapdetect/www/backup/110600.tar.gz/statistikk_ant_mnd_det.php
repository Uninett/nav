<?php require('include.inc'); ?>
<?php require('statistikk.inc'); ?>

<?php tittel("TrapDetect") ?>

<p>
Denne siden viser oversikt over hvilke enheter som har sendt ut denne trap'en. Oversikten er begrenset til � vise
antall traps, mer detaljert informasjon m� finnes p� status, eller i hendelsesregistret.
</p>

<?php topptabell(statistikk) ?>

<?php

	if ($antdager == 1) {
		echo "<center><p><h3>Antall $oid-traps sendt fra enheter i perioden $antdager dag siden til i dag.</h3></p></center>\n";
	} else {
		echo "<center><p><h3>Antall $oid-traps sendt fra enheter i perioden $antdager dager siden til i dag.</h3></p></center>\n";
	}

	$fortsett = 1;
	$teller = 0;
	$max = 0;
	array ($data);
	while (($teller <= $antdager) && $fortsett) {
		if ($teller == 0) {
			$filename = "/home/trapdet/statistikk/oiddag.dat";
			list ($data,$max) = lagDataDet("ant", $filename, $oid);
		} else {
			# Finner navn til fila.
			$dato = date("dmy", mktime(0,0,0,date("m"),date("d")-$teller,date("Y")));
			$filename = "/home/trapdet/statistikk/log/oiddag.dat$dato";
	
			if (is_file ($filename)) {
				list ($tempdata,$tempmax) = lagDataDet("ant", $filename, $oid);
				if ($tempmax > 0) {
					while (list ($key, $value) = each ($tempdata)) {
						$data[$key] += $value;
						if ($data[$key] > $max) {
							$max = $data[$key];
						}
					}
				}
			} else {
				$fortsett = 0;
			}
		}
		$teller++;
	}


if ($fortsett) {
	# Lager bilde fra arrayet
	list ($imagemap, $bilde) = tegnBilde($data, $max);

	echo "<center><img src=\"gif/$bilde.gif\" usemap=\"#map\" border=0></center>\n";

	$antall = sizeof($imagemap);
	echo "<map name=\"map\">";
	for ($i = 0; $i < $antall; $i++) {
		$navn = key ($imagemap);
		list($x,$y,$xx,$yy) = $imagemap[$navn];
		echo "<area shape=rect href=\"statistikk_meldinger.php?name=$navn&antdager=$antdager&oid=$oid\" coords=\"$x,$y,$xx,$yy\">\n";
		next($imagemap);
	}
	echo "</map>";

} else {
	print "For mange dager tilbake. Vi har bare lagret data siden ";
	if (date("dmy") > date("dmy", mktime(0,0,0,8,30,2000))) {
		$tomndsiden = date ("d M Y", mktime(0, 0, 0, date("m")-2, 1, date("Y")));
		print "$tomndsiden.<br>\n";
	} else {
		print "24 July 2000.<br>\n";
	}
}

?>



<?php bunntabell() ?>
