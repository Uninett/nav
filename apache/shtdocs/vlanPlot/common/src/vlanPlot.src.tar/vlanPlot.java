/*
 * NTNU ITEA Nettnu prosjekt
 *
 * Dette programmet er laget slik at det kan kj�res b�de som en vanlig
 * applikasjon og som en applet. Merk at programmet m� ha n�dvendig
 * tilgang dersom det kj�res som applet.
 *
 * Skrvet av: Kristian Eide
 *
 */

import java.applet.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;


public class vlanPlot extends Applet
{

	// For � kj�re programmet som applikasjon
	public static void main(String[] args)
	{
		Frame f = new frame();
		//f = new frame();
		f.show();
	}

	// For � kj�re programmet som applet
	public void init()
	{
//		setLocation(150, 150);
		setSize(800, 600);

		Com com = new Com();

		//com.setDocumentBase(getDocumentBase() );
		com.setApplet(this);

		Keyl keyl = new Keyl(com);
		Mouse mouse = new Mouse(com);
		MouseMove mv = new MouseMove(com);

		com.setKeyl(keyl);
		com.setMouse(mouse);
		com.setMouseMove(mv);

		addKeyListener(keyl);
//		addMouseMotionListener(ml);

		setLayout(new GridLayout(1, 1));
		add(new panel(com));

	}
}

class frame extends Frame
{
	public frame()
	{
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		} );

		setLocation(150, 150);
		setSize(800, 620);

		Com com = new Com();

		Keyl keyl = new Keyl(com);
		Mouse mouse = new Mouse(com);
		MouseMove mv = new MouseMove(com);

		com.setKeyl(keyl);
		com.setMouse(mouse);
		com.setMouseMove(mv);

		addKeyListener(keyl);
//		addMouseMotionListener(ml);

		add(new panel(com));
	}
}

class panel extends Panel
{
	int DEBUG_LEVEL = 10;

	Com com;

	public panel(Com InCom)
	{
		com = InCom;
		setBackground(Color.white);

		if (System.getProperty("java.vendor").equals("Netscape Communications Corporation")) {
			DEBUG_LEVEL = 0;
		}

		Admin admin = new Admin(com);
		com.setAdmin(admin);
		com.setDebugLevel(DEBUG_LEVEL);
		com.setMainPanel(this);

		// Sett parametere fra HTML-filen, hvis dette er en applet, ellers brukes default-verdier
		initParameters();

		// jepp, gridbag m� til
		GridBagLayout gridbag = new GridBagLayout();
		setLayout(gridbag);
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH;

		// Left
		Left l = new Left(com); //l.setSize(100, 100);
		c.weightx = 0; c.weighty = 100;
		c.gridx = 1; c.gridy = 1; c.gridwidth = 1; c.gridheight = 3;
		//c.ipadx = 100;
		//c.ipady = 100;
		gridbag.setConstraints(l, c);
		add(l, c);
		com.setLeft(l);

		// Top scrollbar
		Scrollbar topScroll = new Scrollbar(Scrollbar.HORIZONTAL, 0, 1, 0, 1); // init, visible, min, max
		c.weightx = 0; c.weighty = 0;
		c.gridx = 2; c.gridy = 1; c.gridwidth = 8; c.gridheight = 1;
		c.ipadx = 0;
		gridbag.setConstraints(topScroll, c);
		add(topScroll, c);
		com.setTopScroll(topScroll);

		// Middle scrollbar
		Scrollbar midScroll = new Scrollbar(Scrollbar.VERTICAL, 0, 1, 0, 1);
		c.weightx = 0; c.weighty = 0;
		c.gridx = 10; c.gridy = 1; c.gridwidth = 1; c.gridheight = 3;
		//c.ipadx = 0;
		gridbag.setConstraints(midScroll, c);
		add(midScroll, c);
		com.setMidScroll(midScroll);

		// Bottom scrollbar
		Scrollbar bottomScroll = new Scrollbar(Scrollbar.HORIZONTAL, 0, 1, 0, 1);
		c.weightx = 0; c.weighty = 0;
		c.gridx = 2; c.gridy = 3; c.gridwidth = 8; c.gridheight = 1;
		//c.ipadx = 0;
		gridbag.setConstraints(bottomScroll, c);
		add(bottomScroll, c);
		com.setBottomScroll(bottomScroll);

		// Net
		Net n = new Net(com);
		c.weightx = 100; c.weighty = 100;
		c.gridx = 2; c.gridy = 2; c.gridwidth = 8; c.gridheight = 1;
		//c.ipadx = 600;
		//c.ipady = 0;
		gridbag.setConstraints(n, c);
		add(n, c);
		com.setNet(n);




/*
		// OLD GRIDBAG
		// jepp, gridbag m� til
		GridBagLayout gridbag = new GridBagLayout();
		setLayout(gridbag);
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH;

		// Left
		Left l = new Left(com);
		c.weightx = 0; c.weighty = 0;
		c.gridx = 1; c.gridy = 1; c.gridwidth = 1; c.gridheight = 1;
		//c.ipady = 100;
		//c.ipady = 100;
		gridbag.setConstraints(l, c);
		add(l, c);
		com.setLeft(l);

		// Net
		Net n = new Net(com);
		c.weightx = 100; c.weighty = 100;
		c.gridx = 2; c.gridy = 1; c.gridwidth = 8; c.gridheight = 1;
		//c.ipady = 100;
		//c.ipady = 0;
		gridbag.setConstraints(n, c);
		add(n, c);
		com.setNet(n);
*/




		n.showBynett();

	}

	private void initParameters()
	{
		Applet a = com.getApplet();
		String vPServerURL, lastURL, cricketURL, netflowURL;

		if (a == null) {
			com.d("Ikke applet, bruker default-parametere", 1);
			vPServerURL = Input.vPServerURLDefault;
			lastURL = Input.lastURLDefault;
			cricketURL = Input.cricketURLDefault;
			netflowURL = Input.netflowURLDefault;
		} else {
			com.d("Henter parametere fra HTML-fil", 1);
			vPServerURL = a.getParameter("vPServerURL");
			lastURL = a.getParameter("lastURL");
			cricketURL = a.getParameter("cricketURL");
			netflowURL = a.getParameter("netflowURL");
		}
		Input.vPServerURL = vPServerURL;
		Input.lastURL = lastURL;
		Input.cricketURL = cricketURL;
		Input.netflowURL = netflowURL;
	}

	public void setWaitCursor()
	{
		setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR) );
	}
	public void setDefaultCursor()
	{
		setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR) );
	}
}






